using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace IdentityMongoDBt1.Areas.Identity.Pages.Account
{
    public class RegisterConfrimationModel : PageModel
    {
        public void OnGet()
        {
        }
        [HttpGet]
        public IActionResult RegisterConfrimation()
        {
            return Page();
        }
    }
}
