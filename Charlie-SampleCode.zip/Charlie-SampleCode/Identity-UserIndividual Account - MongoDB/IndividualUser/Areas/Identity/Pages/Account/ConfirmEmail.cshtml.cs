﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using IdentityMongoDBt1.Models;

namespace IdentityMongoDBt1.Areas.Identity.Pages.Account
{
    [AllowAnonymous]
    public class ConfirmEmailModel : PageModel
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager; 

        public ConfirmEmailModel(UserManager<ApplicationUser> userManager,SignInManager<ApplicationUser> signInManager)
        {
            _signInManager = signInManager; 
            _userManager = userManager;
        }

        public async Task<IActionResult> OnGetAsync(string userId, string code, string email)
        {
            if (code == null || userId == null || email == null)
            {
                System.Diagnostics.Debug.WriteLine("*******Empty Response. Null for UserID and null for Code*******");
                return RedirectToPage("/Index");
            }
            else
            {
                var user = await _userManager.FindByIdAsync(userId); 
                var userSignedIn = await _userManager.FindByEmailAsync(email);
               
                if (user == null)
                {
                    return NotFound($"Unable to load user with ID '{userId}'.");
                }
                else
                {
                    var result = await _userManager.ConfirmEmailAsync(user, code);
                                                                                  
                    if (!result.Succeeded)
                    {
                        throw new InvalidOperationException($"Error confirming email for user with ID '{user}':");
                    }
                    else
                    {
                        await _signInManager.SignInAsync(userSignedIn, isPersistent: false);
                                                                                            
                        return Page();
                    }

                   
                }

                
            }
           
        }
    }
}
