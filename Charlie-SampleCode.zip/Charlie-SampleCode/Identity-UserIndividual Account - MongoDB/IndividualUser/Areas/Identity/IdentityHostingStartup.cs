﻿using System;
using IdentityMongoDBt1.Data;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;


using Microsoft.AspNetCore.Authentication.Cookies;
using MongoDB.Bson;
using IdentityMongoDBt1.Areas.Identity;
using IdentityMongoDBt1.Areas.Identity.Stores;
using IdentityMongoDBt1.Models;
using IdentityMongoDBt1.Areas.Identity.Services;

using Microsoft.AspNetCore.Identity.UI.Services;

[assembly: HostingStartup(typeof(IdentityMongoDBt1.Areas.Identity.IdentityHostingStartup))]
namespace IdentityMongoDBt1.Areas.Identity
{
    public class IdentityHostingStartup : IHostingStartup
    {

        public void Configure(IWebHostBuilder builder)
        {
            builder.ConfigureServices((context, services) => {
                
                services.AddTransient<MongoTablesFactory>();//add to install database
                services.AddAuthorization(opt => {
                    opt.AddPolicy("Administrator",policyBuilder => policyBuilder.RequireRole("Admin"));
                });//till here add for database roles

                services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(CookieAuthenticationDefaults.AuthenticationScheme, opt => {
                    opt.Cookie.Name = "IdentityCookie";
                });
                //AddDefaultIdentity
                services.AddIdentity<ApplicationUser, ApplicationRole>(options =>
                {

                    options.User.RequireUniqueEmail = true;         //uncomment this must implement in Store "IUserEmailStrore<TUser>"
                    options.SignIn.RequireConfirmedEmail = true;    //uncomment this must implement in Store "IUserEmailStrore<TUser>"
                    options.Password.RequireLowercase = true;
                    options.Password.RequireUppercase = true;
                    options.Password.RequireNonAlphanumeric = false;

                    //add me for Lockout features
                   
                    options.Lockout.AllowedForNewUsers = true;
                    options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(1);//duration of locakout
                    options.Lockout.MaxFailedAccessAttempts = 3; //3x attempts only
                    //--till here

                    //add for custom token provider
                    options.Tokens.ProviderMap.Add("CustomEmailConfirmation", new TokenProviderDescriptor(typeof(CustomEmailConfirmationTokenProvider<ApplicationUser>)));
                    options.Tokens.EmailConfirmationTokenProvider = "CustomEmailConfirmation";
                    //tiill herre ----

                })
                .AddDefaultUI()
                .AddDefaultTokenProviders() 
                .AddRoleStore<MongoRoleStore<ApplicationRole, ObjectId>>()
                .AddUserStore<MongoUserStore<ApplicationUser, ObjectId>>();
                //modified till here
                services.AddScoped<IUserClaimsPrincipalFactory<ApplicationUser>, AdditionalUserClaimsPrincipalFactory>();//add scoped
                services.AddTransient<CustomEmailConfirmationTokenProvider<ApplicationUser>>();//add me for custom email token provider

            });
        }
    }
}