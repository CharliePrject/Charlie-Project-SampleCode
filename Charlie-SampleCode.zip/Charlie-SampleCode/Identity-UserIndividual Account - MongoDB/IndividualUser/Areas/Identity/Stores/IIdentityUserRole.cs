﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IdentityMongoDBt1.Areas.Identity.Stores
{
   public interface IIdentityUserRole
    {
        List<string> Roles { get; set; }

        void AddRole(string role);

        void RemoveRole(string role);
    }
}
