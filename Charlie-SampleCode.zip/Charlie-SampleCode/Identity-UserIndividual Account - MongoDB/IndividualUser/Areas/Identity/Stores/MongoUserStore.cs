﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Identity;
using MongoDB.Driver;
using MongoDB.Bson;
using System.Threading;

namespace IdentityMongoDBt1.Areas.Identity.Stores
{
    public class MongoUserStore<TUser, TKey> : IUserStore<TUser>, IUserPasswordStore<TUser>, IUserEmailStore<TUser>, IUserRoleStore<TUser> where TUser : IdentityUser<TKey>, IIdentityUserRole where TKey : IEquatable<TKey>   // -- w/ identity IUserEmailStroe & use "Microsoft.AspNet.Identity.EntityFramework"
    {
        private readonly IMongoCollection<TUser> _users;
      

        public MongoUserStore(MongoTablesFactory proxyTables)
        {
            _users = proxyTables.GetCollection<TUser>(MongoTablesFactory.TABLE_USERS);
            
        }
       
        public virtual void Dispose()
        {
           
        }
        public virtual async Task<IdentityResult> CreateAsync(TUser user, CancellationToken token)
        {
            await _users.InsertOneAsync(user, cancellationToken: token);
            return IdentityResult.Success;
        }
        public virtual async Task<IdentityResult> UpdateAsync(TUser user, CancellationToken token)
        {
            await _users.ReplaceOneAsync(x => x.Id.Equals(user.Id), user, cancellationToken: token);
            return IdentityResult.Success;

        }
        public virtual async Task<IdentityResult> DeleteAsync(TUser user, CancellationToken token)
        {
            await _users.DeleteOneAsync(x => x.Id.Equals(user.Id), token);
            return IdentityResult.Success;
        }
        public Task<string> GetUserIdAsync(TUser user, CancellationToken cancellationToken) => Task.FromResult(user.Id.ToString());
        public Task<string> GetUserNameAsync(TUser user, CancellationToken cancellationToken) => Task.FromResult(user.UserName);
        public Task SetUserNameAsync(TUser user, string userName, CancellationToken cancellationToken)
        {
            user.UserName = userName;
            return Task.CompletedTask;
        }
        public Task<string> GetNormalizedUserNameAsync(TUser user, CancellationToken cancellationToken) => Task.FromResult(user.NormalizedUserName);
        public Task SetNormalizedUserNameAsync(TUser user, string normalizedUsername, CancellationToken cancellationToken)
        {
            user.NormalizedUserName = normalizedUsername;
            return Task.CompletedTask;
        }
       
        public Task<string> GetNormalizedEmailAsync(TUser user, CancellationToken cancellationToken) => Task.FromResult(user.NormalizedEmail);
        public Task SetNormalizedEmailAsync(TUser user, string normalizedEmail, CancellationToken cancellationToken)
        {
            user.NormalizedEmail = normalizedEmail;
            return Task.CompletedTask;
        }

        public async Task<TUser> FindByIdAsync(string userId, CancellationToken cancellationToken = default)
        {
            ObjectId toId = ObjectId.Parse(userId);
            cancellationToken.ThrowIfCancellationRequested();
            return await _users.Find(x => x.Id.Equals(toId)).SingleOrDefaultAsync(cancellationToken);
        }
        private bool IsObjecId(string id)
        {
            ObjectId _id;
            return ObjectId.TryParse(id,out _id);
        }
        public virtual Task<TUser> FindByNameAsync(string normalizedUserName, CancellationToken token) => _users.Find(x => x.NormalizedUserName == normalizedUserName).FirstOrDefaultAsync(token);
        public Task SetPasswordHashAsync(TUser user, string passwordHash, CancellationToken token)
        {
            user.PasswordHash = passwordHash;
            return Task.CompletedTask;
        }
        public Task<string> GetPasswordHashAsync(TUser user, CancellationToken token) => Task.FromResult(user.PasswordHash);
       
        public Task<bool> HasPasswordAsync(TUser user, CancellationToken cancellationToken) => Task.FromResult(false);
        public Task AddToRoleAsync(TUser user, string roleName, CancellationToken cancellationToken)
        {
            user.AddRole(roleName);
            return Task.CompletedTask;
        }
        public Task RemoveFromRoleAsync(TUser user, string roleName, CancellationToken cancellationToken)
        {
            user.RemoveRole(roleName);
            return Task.CompletedTask;
        }
        public async Task<IList<string>> GetRolesAsync(TUser user, CancellationToken cancellationToken)
        {
            var roles = user.Roles?.ToArray() ?? Array.Empty<string>();
            return await Task.FromResult(roles);
        }
        public async Task<bool> IsInRoleAsync(TUser user, string roleName, CancellationToken cancellationToken)
        {
            var roles = await GetRolesAsync(user, cancellationToken);
            return roles.Contains(roleName);
        }
        public Task<IList<TUser>> GetUsersInRoleAsync(string roleName, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public Task SetEmailAsync(TUser user, string email, CancellationToken cancellationToken)
        {
            //throw new NotImplementedException();
            cancellationToken.ThrowIfCancellationRequested();
            if (user == null)
            {
                throw new ArgumentNullException(nameof(user));
            }
            user.UserName = email;
            return Task.FromResult<object>(null);
        }

        public Task<string> GetEmailAsync(TUser user, CancellationToken cancellationToken) 
        {
            cancellationToken.ThrowIfCancellationRequested();
            if(user == null)
            {
              throw new  ArgumentNullException(nameof(user));
            }
            return Task.FromResult(user.Email);
        }
        public Task<bool> GetEmailConfirmedAsync(TUser user,CancellationToken cancellationToken = default)
        {
            // throw new NotImplementedException();
            //return Task.FromResult(true);//set result must be "true" otherwise email cant verify(if (user == null || !(await _userManager.IsEmailConfirmedAsync(user)))) and not found im "forgotpassword"
            return Task.FromResult(true);
        }
        public Task SetEmailConfirmedAsync(TUser user, bool confirmed, CancellationToken cancellationToken = default)
        {

            user.EmailConfirmed = confirmed;
            return Task.FromResult(0);//test add me set custom EmailConfirmed = true or verified as " confirmed"
            //return Task.FromResult<object>(null);
        }

        public async Task<TUser> FindByEmailAsync(string normalizedEmail, CancellationToken cancellationToken = default)//modified for "forgotpassword"
        {
           String toFormat = normalizedEmail.ToLower();//convert into lowercase
           cancellationToken.ThrowIfCancellationRequested();
           return await _users.Find(x => x.UserName.Equals(toFormat)).SingleOrDefaultAsync(cancellationToken);
            //return await _users.Find(x => x.UserName.Equals("charcy.test@gmail.com")).SingleOrDefaultAsync(cancellationToken);//for FindByEmailAsync is always looking for "normalizedEmail" value. If normalizedEmail = null, then you will encountred this error:"Unable to load user with ID '{email}'" -> its because FindByEmailAsync returns alwasy NULL. Selecting specific value/parameters for normalized email if only for test like this. Note: study how to configure normalizedEmail here in MongoUserStore "IEmailUserStore<TUser>"
        }
        // public async virtual Task<TUser> FindByEmailAsync(string email,CancellationToken token) => await _users.Find(x=>x.UserName.Equals(email)).SingleOrDefaultAsync(cancellationToken: token);//test
        //lockout starthere
        //public Task<bool> GetLockoutEnabledAsync(TUser user,CancellationToken cancellationToken = default)//lockoutenable set manually: Add Me
        //{
        //    return Task.FromResult(true);
        //}
        //public Task SetLockoutEnabledAsync(TUser user, bool enabled, CancellationToken cancellationToken = default)
        //{

        //    user.LockoutEnabled = enabled;//test add me
        //    return Task.FromResult(0);//test add me
          
        //}

        //public Task<DateTimeOffset?> GetLockoutEndDateAsync(TUser user, CancellationToken cancellationToken)
        //{
        //    return Task.FromResult(user.);
        //}

        //public Task SetLockoutEndDateAsync(TUser user, DateTimeOffset? lockoutEnd, CancellationToken cancellationToken)
        //{
        //   DateTime
        //}

        //public Task<int> IncrementAccessFailedCountAsync(TUser user, CancellationToken cancellationToken)
        //{
        //    throw new NotImplementedException();
        //}

        //public Task ResetAccessFailedCountAsync(TUser user, CancellationToken cancellationToken)
        //{
        //    throw new NotImplementedException();
        //}

        //public Task<int> GetAccessFailedCountAsync(TUser user, CancellationToken cancellationToken)
        //{
        //    throw new NotImplementedException();
        //}

       
        //public Task<string> GetNormalizedEmailAsync(TUser user, CancellationToken cancellationToken = default) )//give null value for NormalizedEmail
        //{
        //    cancellationToken.ThrowIfCancellationRequested();
        //    if (user == null)
        //    {
        //        throw new ArgumentNullException(nameof(user));
        //    }
        //    return Task.FromResult(user.UserName);
        //}

        //public Task SetNormalizedEmailAsync(TUser user, string normalizedEmail, CancellationToken cancellationToken = default)//give null value for NormalizedEmail
        //{
        //    return Task.FromResult<object>(null);
        //}
        //--till here

    }//class end

}
