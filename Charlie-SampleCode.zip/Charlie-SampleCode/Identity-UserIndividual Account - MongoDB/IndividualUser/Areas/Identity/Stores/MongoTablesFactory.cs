﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


using MongoDB.Bson;
using MongoDB.Driver;
using Microsoft.Extensions.Configuration;

namespace IdentityMongoDBt1.Areas.Identity.Stores
{
    public class MongoTablesFactory
    {
       
        public const string TABLE_USERS = "Users";
        public const string TABLE_ROLES = "Roles";
        public IMongoDatabase db;
        public MongoTablesFactory(IConfiguration conf)
        {
             MongoClient client = new MongoClient(conf.GetConnectionString("database"));
             db = client.GetDatabase("database");
            
        }
        public IMongoCollection<T> GetCollection<T>(string tableName)
        {
            return db.GetCollection<T>("ApplicationUser");
        }
    }//end class
}
