﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.Net;
using System.Net.Mail;
using System.Text;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.Extensions.Options;




namespace IdentityMongoDBt1.Areas.Identity.Services
{
    public class EmailSender: IEmailSender
    {
        private string host,username,password;
        private int port;
        private bool enableSSL;

        public EmailSender(string _host, int _port, bool _enableSSL, string _username,string _password)
        {
            this.host = _host;
            this.port = _port;
            this.enableSSL = _enableSSL;
            this.username = _username;
            this.password = _password;
            
        }
        public Task SendEmailAsync(string email, string subject, string message)
        {
            var client = new SmtpClient(host, port)
            {
                Credentials = new NetworkCredential(username,password),
                EnableSsl = enableSSL
            };
            subject = "Email Confirmation";
            return client.SendMailAsync(new MailMessage(username, email, subject, message) { IsBodyHtml=true});

        }

    }//end of class
}
