﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;


namespace IdentityMongoDBt1.Areas.Identity.Services
{
    public class CustomEmailConfirmationTokenProvider<Tuser>: DataProtectorTokenProvider<Tuser> where Tuser : class
    {
        public CustomEmailConfirmationTokenProvider(IDataProtectionProvider dataProtectionProvider, IOptions<EmailConfirmationTokenProviderOptions> options) : base(dataProtectionProvider,options) { }
        public class EmailConfirmationTokenProviderOptions : DataProtectionTokenProviderOptions
        {
            public EmailConfirmationTokenProviderOptions()
            {
                Name = "EmailConfirmationTokenProviderOptions";
                TokenLifespan = TimeSpan.FromHours(3);
            }
        }
    }//class end
}
