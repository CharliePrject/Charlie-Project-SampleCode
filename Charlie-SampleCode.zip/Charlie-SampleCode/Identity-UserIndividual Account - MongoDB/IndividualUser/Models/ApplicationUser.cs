﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


using Microsoft.AspNetCore.Identity;//
using MongoDB.Bson;//
using MongoDB.Driver;//
using System.Threading;//
using IdentityMongoDBt1.Areas.Identity.Stores;//

namespace IdentityMongoDBt1.Models
{
    public class ApplicationUser : IdentityUser<ObjectId>,IIdentityUserRole
    {
        [PersonalData]
        public string Name { get; set; }
        public string Firstname { get; set; }//
        [PersonalData]
        public string LastName { get; set; }//
        [PersonalData]
        public string Birthday { get; set; }//
        [PersonalData]
        public string Gender { get; set; }//
        [PersonalData]
        public string Address { get; set; }//
        public bool IsAdmin { get; set; }
        public virtual List<string> Roles { get; set; }
        public ApplicationUser()
        {
            Roles = new List<string>();
        }
        public virtual void AddRole(string role)
        {
            Roles.Add(role);
        }
        public virtual void RemoveRole(string role)
        {
            Roles.Remove(role);
        }
    }//class end
}
