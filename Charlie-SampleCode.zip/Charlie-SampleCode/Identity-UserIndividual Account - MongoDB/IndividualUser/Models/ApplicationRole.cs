﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Identity; //
using MongoDB.Bson; //
using System.Threading;//
using MongoDB.Driver;//


namespace IdentityMongoDBt1.Models
{
    public class ApplicationRole : IdentityRole<ObjectId>
    {
        public override ObjectId Id { get; set; }
        public ApplicationRole()
        {

        }
        public ApplicationRole(string roleName): this()
        {
            Name = roleName;
        }
    }//end class
}
