﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Npgsql;
using MetroFramework;
using MetroFramework.Forms;
using System.Runtime.InteropServices;

namespace GUI
{
    public partial class GUI : Form
    {
        string sr = "SERVER=;PORT=;USERNAME=;PASSWORD=;DATABASE=";
        NpgsqlConnection conn = new NpgsqlConnection(sr);
        DataTable dt = new DataTable();
        DataTable dt_logo = new DataTable();
        DataTable dt_textcrawl = new DataTable();
        DataTable dt_playout = new DataTable();
       
        public int sec_module, method1,s_start, moduleType, s_cout_Chan, s_batchID,s_db_batch_id,pos,s_c_primID;
        public string resolution,s_c_name,s_c_module,s_c_trigger_status;

        public int timer_start_sec, timer_start_min, timer_end_min, timer_end_sec = 1;
        public int a,set_time,p_duration;
        public int vOffset, hOffset;
       
        public int t_min, t_sec, t_miliSec, t_val, playout_length, aa;
        bool _isActive, _isPlayout_timer;



        //------------ DLL importing ----------------------------------------------
        [DllImport(@"", EntryPoint = "main")]//
        public static extern int main();
        [DllImport(@"", EntryPoint = "", CallingConvention = CallingConvention.Cdecl)]
        [System.Security.SecurityCritical]
        public static extern bool AskForRegistrationID(int cbsRegistrationID);

        [DllImport(@"", EntryPoint = "", CallingConvention = CallingConvention.Cdecl)]
        [System.Security.SecurityCritical]
        public static extern bool AskForVersionInfo(double cbsVersionInfo);
        [DllImport(@"", EntryPoint = "", CharSet = CharSet.Ansi)]
        
        [System.Security.SecurityCritical]
        public static extern bool AskForIP(string bstrIP, int nPort);

        [DllImport(@"", EntryPoint = "", CallingConvention = CallingConvention.Cdecl)]
        
        [System.Security.SecurityCritical]
        public static extern bool AskForControlType(long lType);
        [DllImport(@"", EntryPoint = "", CallingConvention = CallingConvention.Cdecl)]
        
        [System.Security.SecurityCritical]
        public static extern bool AskforEnaModules(int module);

        [DllImport(@"", EntryPoint = "", CallingConvention = CallingConvention.Cdecl)]
        [System.Security.SecurityCritical]
        public static extern bool AskforChannelObjID(string channelID);

        //---------------
       
        [DllImport(@"", EntryPoint = "", CallingConvention = CallingConvention.Cdecl)]
       
        [System.Security.SecurityCritical]
        public static extern bool AskForBatchID(int batchID);

       
        [DllImport(@"", EntryPoint = "", CallingConvention = CallingConvention.Cdecl)]
        [System.Security.SecurityCritical]
        public static extern bool AskForTextCrawlStatus(string TextCrawlStatus);

      
        [DllImport(@"", EntryPoint = "", CallingConvention = CallingConvention.Cdecl)]
        [System.Security.SecurityCritical]
        public static extern bool AskForTextCrawlEnaDis(int ltxtcrawlEna);

      
        [DllImport(@"", EntryPoint = "", CallingConvention = CallingConvention.Cdecl)]
       
        [System.Security.SecurityCritical]
        public static extern bool AskForPlayoutStatus(string cbsPlayoutStatus);

        //-------------------------------------------------------------------



        public GUI()
        {
            InitializeComponent();
        }

        private void GUI_Load(object sender, EventArgs e)
        {
            CenterToParent();
            showtable("", CHANNELS);

          
            panel_file_list.Hide();

      
            timer_date_time.Start();
            lbl_date.Text = DateTime.Now.ToLongDateString();
            lbl_time.Text = DateTime.Now.ToLongTimeString();


        
            btn_auto_start_end.Enabled = false;
            lbl_start_end.Visible = false;


     
            groupBox_progressbar.Hide();

        }
        private void showtable(string qry, ListView lv1)
        {

            try
            {
                conn.Open();
                NpgsqlDataAdapter sda = new NpgsqlDataAdapter(qry, conn);

                sda.Fill(dt);
                lv1.Clear();
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    DataRow dr = dt.Rows[i];
                    ListViewItem lvitem = new ListViewItem(dr[0].ToString());

                    lvitem.SubItems.Add(dr[1].ToString());
                 

                    lv1.Items.Add(lvitem);
                }
                lv1.View = View.Details;
                lv1.FullRowSelect = true;
                lv1.GridLines = true;

              
                lv1.Columns.Add("Channel Name");
                lv1.Columns.Add("Resolution");


                //auto resize the columns
                lv1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
                lv1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);


                conn.Close();
            }


            catch (Exception ex)
            {
                MetroMessageBox.Show(this, "" + ex.Message.ToString(), "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }
        private void showtable_flogo(string qry, ListView lv1)
        {

            try
            {
                conn.Open();
                NpgsqlDataAdapter sda = new NpgsqlDataAdapter(qry, conn);

                sda.Fill(dt_logo);
                lv1.Clear();
                for (int j = 0; j < dt_logo.Rows.Count; j++)
                {
                    DataRow dr = dt_logo.Rows[j];
                    ListViewItem lvitem = new ListViewItem(dr[0].ToString());

                    lvitem.SubItems.Add(dr[1].ToString());
                  
                    lv1.Items.Add(lvitem);
                }
                lv1.View = View.Details;
                lv1.FullRowSelect = true;
                lv1.GridLines = true;

                // lv1.Columns.Add("ID");
                lv1.Columns.Add("Logo Name");
                lv1.Columns.Add("Resolution");


                //auto resize the columns
                lv1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
                lv1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);


                conn.Close();
            }


            catch (Exception ex)
            {
                MetroMessageBox.Show(this, "" + ex.Message.ToString(), "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void showtable_ftextcrawl(string qry, ListView lv1)
        {

            try
            {
                conn.Open();
                NpgsqlDataAdapter sda = new NpgsqlDataAdapter(qry, conn);

                sda.Fill(dt_textcrawl);
                lv1.Clear();
                for (int j = 0; j < dt_textcrawl.Rows.Count; j++)
                {
                    DataRow dr = dt_textcrawl.Rows[j];
                    ListViewItem lvitem = new ListViewItem(dr[0].ToString());

                    lvitem.SubItems.Add(dr[1].ToString());
                   

                    lv1.Items.Add(lvitem);
                }
                lv1.View = View.Details;
                lv1.FullRowSelect = true;
                lv1.GridLines = true;

              
                lv1.Columns.Add("TextCrawl Name");
                lv1.Columns.Add("Resolution");


            
                lv1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
                lv1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);


                conn.Close();
            }


            catch (Exception ex)
            {
                MetroMessageBox.Show(this, "" + ex.Message.ToString(), "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        private void showtable_fplayout(string qry, ListView lv1)
        {

            try
            {
                conn.Open();
                NpgsqlDataAdapter sda = new NpgsqlDataAdapter(qry, conn);

                sda.Fill(dt_playout);
                lv1.Clear();
                for (int j = 0; j < dt_playout.Rows.Count; j++)
                {
                    DataRow dr = dt_playout.Rows[j];
                    ListViewItem lvitem = new ListViewItem(dr[0].ToString());

                    lvitem.SubItems.Add(dr[1].ToString());
                  

                    lv1.Items.Add(lvitem);
                }
                lv1.View = View.Details;
                lv1.FullRowSelect = true;
                lv1.GridLines = true;
 
                lv1.Columns.Add("Playout Name");
                lv1.Columns.Add("Resolution");


            
                lv1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
                lv1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);


                conn.Close();
            }


            catch (Exception ex)
            {
                MetroMessageBox.Show(this, "" + ex.Message.ToString(), "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
      
       
     
        private void get_IP()
        {
            try
            {
                conn.Open();
                //NpgsqlCommand cmd = new NpgsqlCommand("select s_ip_address,s_port from tbl_nmx_configuration WHERE s_ip_id = 2", conn);
                NpgsqlCommand cmd = new NpgsqlCommand("select s_ip_address,s_port from tbl_nmx_configuration WHERE s_ip_id = 1", conn);
                NpgsqlDataReader sdr = cmd.ExecuteReader();

                if (sdr.Read())
                {
                    string ip = sdr.GetValue(0).ToString();
                    int port = Int32.Parse(sdr.GetValue(1).ToString());

                    if (ip.Length > 0 && port != 0)
                    {
                        AskForIP(ip, port);
                        method1 = 1;
                        // main();
                    }

                }

                conn.Close();
            }
            catch (Exception ex)
            {
                MetroMessageBox.Show(this, "Error:    " + ex.Message.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void get_default_NMX_specs()
        {
            try
            {
                conn.Open();
                NpgsqlCommand cmd = new NpgsqlCommand("select s_channel_id,s_nmx_version from tbl_nmx_configuration WHERE s_ip_id = 2", conn);
                NpgsqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    int s_channel_id = Int32.Parse(sdr.GetValue(0).ToString());
                    double s_nmx_version = double.Parse(sdr.GetValue(1).ToString());
                  //  MessageBox.Show(s_nmx_version.ToString());
                    if (method1 == 1)
                    {
                        if (AskForRegistrationID(s_channel_id))//default = 15
                        {

                            AskForVersionInfo(s_nmx_version);//3.0
                            method1 = 2;
                          

                        }
                    }
                }
                conn.Close();
            }
            catch (Exception ex)
            {

            }
        }

      private void s_cntrl_type()
        {
            try
            {
                conn.Open();
                NpgsqlCommand cmd = new NpgsqlCommand("select s_cntrl_type_start from tbl_nmx_configuration WHERE s_ip_id = 2", conn);
                NpgsqlDataReader sdr = cmd.ExecuteReader();
                //while (sdr.Read())
                if(sdr.Read())
                {
                     s_start = Int32.Parse(sdr.GetValue(0).ToString());
                    //MessageBox.Show(s_start.ToString());
                     method1 = 2;
                    conn.Close();//close here to avoid connection error open
                    s_ctrl_type_start();

                  

                }
              
            }
            catch (Exception ex)
            {

            }
        }
        private void s_ctrl_type_start()
        {
            if (method1 == 2)
            {
                // string serv_start ="1";
                long c_s_start = Convert.ToInt64(s_start);
                //MessageBox.Show(c_s_start.ToString());
                if (AskForControlType(c_s_start))
                {

                    if (sec_module == 1)
                    {

                        string toChar = sec_module.ToString();
                        moduleType = sec_module;
                        char ch = char.Parse(toChar);
                        switchModule(ch);

                    }
                    else if (sec_module == 2)
                    {
                        string toChar = sec_module.ToString();
                        moduleType = sec_module;
                        char ch = char.Parse(toChar);
                        switchModule(ch);

                    }
                    else if (sec_module == 3)
                    {

                        string toChar = sec_module.ToString();
                        moduleType = sec_module;
                        char ch = char.Parse(toChar);
                        switchModule(ch);

                    }



                    // }

                }


            }


        }
        public string switchModule(char m)
        {
            switch (m)
            {
                case '1':
                    {
                      
                        if (AskforEnaModules(moduleType))
                        {
                           
                            EnaDisLogo();
                            MetroMessageBox.Show(this,"Done","Info",MessageBoxButtons.OK,MessageBoxIcon.Question);


                        }

                        
                        break;
                    }
                case '2':
                    {
                      
                        if (AskforEnaModules(moduleType))
                        {
                            EnaDisTextCrawl();
                            MetroMessageBox.Show(this, "Done", "Info", MessageBoxButtons.OK, MessageBoxIcon.Question);
                        }

                        break;
                    }
                case '3':
                    {
                      
                        if (AskforEnaModules(moduleType))
                        {
                            EnaDisPlayout();
                            MetroMessageBox.Show(this, "Done", "Info", MessageBoxButtons.OK, MessageBoxIcon.Question);
                        }

                        break;
                    }
                default:
                    {
                       
                        break;
                    }
            }
            return default;
        }
      
        private void EnaDisLogo()
        {
            if(comboBox_Logo.SelectedItem.ToString()!=null)
            {

          
            int c_s_coount = s_cout_Chan;
           
            
              
                try
                {
                   

                    for (int i = 0; i < c_s_coount; i++)
                    {
                        conn.Open();
                    
                        string sec_channel = listBox_selected_Channels.Items[i].ToString();
                        s_c_name = sec_channel;
                        s_c_module = "PNG";
                        
                        
                        NpgsqlCommand cmd = new NpgsqlCommand(" = '" +sec_channel.ToString()+ "'", conn);
                        NpgsqlDataReader sdr = cmd.ExecuteReader();

                       
                        s_batchID = s_db_batch_id + i;
                        if (sdr.Read())
                            {

                         string chanID = sdr["object_id"].ToString(); 
                           
                                int b_ID = s_batchID;
                               
                                    if (AskForBatchID(b_ID))
                                    {
                           
                                        if (AskforChannelObjID(chanID))
                                        {
                                      
                                        conn.Close();
                                        sec_Logo();
                                        managedata_batch_used("insert )");


                                }
                                    }

                            }
                           

                    }//loop end bracket
                    

                }//try end bracket
                catch (Exception ex)
                {
                    MetroMessageBox.Show(this, "" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
        }
        private void EnaDisTextCrawl()
        {


            if (comboBox_Textcrawl.SelectedItem.ToString() != null)
            {

              
                int c_s_coount = s_cout_Chan;
                
  
                try
                {


                    for (int i = 0; i < c_s_coount; i++)
                    {
                        conn.Open();
                        
                        string sec_channel = listBox_selected_Channels.Items[i].ToString();

                        s_c_name = sec_channel;
                        s_c_module = "SWF";


                        NpgsqlCommand cmd = new NpgsqlCommand("select '" + sec_channel.ToString() + "'", conn);
                        NpgsqlDataReader sdr = cmd.ExecuteReader();

                      
                        s_batchID = s_db_batch_id + i;

                        if (sdr.Read())
                        {

                           
                            string chanID = sdr["object_id"].ToString(); 

                            int b_ID = s_batchID;
                        
                            if (AskForBatchID(b_ID))
                            {

                                if (AskforChannelObjID(chanID))
                                {
                                   
                                    conn.Close();
                                    sec_textcrawl();
                                    managedata_batch_used("insert )");

                                }
                            }

                        }


                    }


                }
                catch (Exception ex)
                {
                    MetroMessageBox.Show(this, "" + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }

        }
        private void EnaDisPlayout()
        {


            if (comboBox_Playout.SelectedItem.ToString() != null)
            {

                
                int c_s_coount = s_cout_Chan;
              
                
                try
                {


                    for (int i = 0; i < c_s_coount; i++)
                    {
                        conn.Open();
                      
                        string sec_channel = listBox_selected_Channels.Items[i].ToString();
                        s_c_name = sec_channel;
                        s_c_module = "TS";

                        NpgsqlCommand cmd = new NpgsqlCommand("select'" + sec_channel.ToString() + "'", conn);
                        NpgsqlDataReader sdr = cmd.ExecuteReader();

                       
                        s_batchID = s_db_batch_id + i;
                        if (sdr.Read())
                        {

                           string chanID = sdr["object_id"].ToString(); 
                            int b_ID = s_batchID;
                            if (AskForBatchID(b_ID))
                            {

                                if (AskforChannelObjID(chanID))
                                {
                                    conn.Close();
                                    sec_playout();
                                    managedata_batch_used("insert)");

                                }
                            }

                        }


                    }//loop end bracket


                }//try end bracket
                catch (Exception ex)
                {
                    //MessageBox.Show(ex.Message.ToString());
                    MetroMessageBox.Show(this,""+ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }

            }


        }

        //---
        private void sec_Logo()
        {
            if(comboBox_Logo.SelectedIndex>-1 && sec_module == 1)
            {

            
                try
                {
                    conn.Open();
                    NpgsqlCommand cmd = new NpgsqlCommand("select  '"+comboBox_Logo.SelectedItem.ToString()+"'AND resolution = '"+resolution+"'", conn);
                    NpgsqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.Read())
                    {
                        string ass_ID = sdr.GetValue(0).ToString();
                        string logoState;
                        int trigger_ena, trigg_dis, logo_tl, logo_tr, logo_bl, logo_br;
                        
                        if (btnlogo.Text == "ON LOGO")
                        {
                            logoState = sdr.GetValue(1).ToString();
                            string off = sdr.GetValue(2).ToString();
                            trigger_ena = Int32.Parse(sdr.GetValue(3).ToString());
                            trigg_dis = Int32.Parse(sdr.GetValue(4).ToString());
                            logo_tl = Int32.Parse(sdr.GetValue(5).ToString());
                            logo_tr = Int32.Parse(sdr.GetValue(6).ToString());
                            logo_bl = Int32.Parse(sdr.GetValue(7).ToString());
                            logo_br = Int32.Parse(sdr.GetValue(8).ToString());
                         

                            s_c_trigger_status = logoState;
                       

                            //enable
                            if (AskForLogoAssetID(ass_ID))
                            {
                               if (AskForLogoStatus(logoState))
                                {
                                    if (pos == 1)
                                    {
                                        int l_ena = trigger_ena;
                                        int l_lImagePos = logo_tl;
                                        int l_logoVoffset = vOffset; 
                                        int l_logoHoffset = hOffset;
                                        AskforLogoEnaTransformationProp(l_ena, l_lImagePos, l_logoVoffset, l_logoHoffset);
                                        main();


                                    }
                                    else if (pos == 2)
                                    {
                                        int l_ena = trigger_ena;
                                        int l_lImagePos = logo_tr;
                                        int l_logoVoffset = vOffset; 
                                        int l_logoHoffset = hOffset;
                                        AskforLogoEnaTransformationProp(l_ena, l_lImagePos, l_logoVoffset, l_logoHoffset);
                                        main();

                                    }
                                    else if (pos == 3)
                                    {
                                        int l_ena = trigger_ena;
                                        int l_lImagePos = logo_bl;
                                        int l_logoVoffset = vOffset; 
                                        int l_logoHoffset = hOffset;
                                        AskforLogoEnaTransformationProp(l_ena, l_lImagePos, l_logoVoffset, l_logoHoffset);
                                        main();

                                    }
                                    else if (pos == 4)
                                    {
                                        int l_ena = trigger_ena;
                                        int l_lImagePos = logo_br;
                                        int l_logoVoffset = vOffset; 
                                        int l_logoHoffset = hOffset;
                                        AskforLogoEnaTransformationProp(l_ena, l_lImagePos, l_logoVoffset, l_logoHoffset);
                                        main();
                                    }
                                    else
                                    {
                                        
                                    }
                                }
                            }




                        }
                        else if(btnlogo.Text == "OFF LOGO")
                        {
                            string on = sdr.GetValue(1).ToString();
                            logoState = sdr.GetValue(2).ToString();
                            trigger_ena = Int32.Parse(sdr.GetValue(3).ToString());
                            trigg_dis = Int32.Parse(sdr.GetValue(4).ToString());
                            logo_tl = Int32.Parse(sdr.GetValue(5).ToString());
                            logo_tr = Int32.Parse(sdr.GetValue(6).ToString());
                            logo_bl = Int32.Parse(sdr.GetValue(7).ToString());
                            logo_br = Int32.Parse(sdr.GetValue(8).ToString());
                          
                            s_c_trigger_status = logoState;

                           
                            if (AskForLogoAssetID(ass_ID))
                            {
                               
                                if (AskForLogoStatus(logoState))
                                {
                                    if (pos == 1)
                                    {
                                        int l_ena = trigg_dis;
                                        int l_lImagePos = logo_tl;
                                        int l_logoVoffset = 10; 
                                        int l_logoHoffset = 10;
                                        AskforLogoEnaTransformationProp(l_ena, l_lImagePos, l_logoVoffset, l_logoHoffset);
                                        main();


                                    }
                                    else if (pos == 2)
                                    {
                                        int l_ena = trigg_dis;
                                        int l_lImagePos = logo_tr;
                                        int l_logoVoffset = 10; 
                                        int l_logoHoffset = 10;
                                        AskforLogoEnaTransformationProp(l_ena, l_lImagePos, l_logoVoffset, l_logoHoffset);
                                        main();

                                    }
                                    else if (pos == 3)
                                    {
                                        int l_ena = trigg_dis;
                                        int l_lImagePos = logo_bl;
                                        int l_logoVoffset = 10; 
                                        int l_logoHoffset = 10;
                                        AskforLogoEnaTransformationProp(l_ena, l_lImagePos, l_logoVoffset, l_logoHoffset);
                                        main();
                                    }
                                    else if (pos == 4)
                                    {
                                        int l_ena = trigg_dis;
                                        int l_lImagePos = logo_br;
                                        int l_logoVoffset = 10; 
                                        int l_logoHoffset = 10;
                                        AskforLogoEnaTransformationProp(l_ena, l_lImagePos, l_logoVoffset, l_logoHoffset);
                                        main();

                                    }
                                    else
                                    {
                                       
                                    }
                                }
                            }
                        }

                      
                        
                    }
                    conn.Close(); 
                }
                catch (Exception ex)
                {

                }

            }

        }
        private void sec_textcrawl()
        {
            if (comboBox_Textcrawl.SelectedIndex > -1 && sec_module == 2)
            {
                try
                {
                    conn.Open();
                    NpgsqlCommand cmd = new NpgsqlCommand("select'" + comboBox_Textcrawl.SelectedItem.ToString() + "'AND resolution = '" + resolution + "'", conn);
                    NpgsqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.Read())
                    {
                        string ass_ID = sdr["asset_id"].ToString(); 
                        string txtcrawlState;
                        int l_txtcrawlEna;

                        //enable
                        if(btn_textcrawl.Text == "ON TEXT CRAWL")
                        {
                            
                             txtcrawlState = sdr["status_on"].ToString();
                             l_txtcrawlEna = Int32.Parse(sdr["trigger_ena"].ToString());

                            s_c_trigger_status = txtcrawlState;
                            if (AskForLogoAssetID(ass_ID))
                            {
                                if (AskForTextCrawlStatus(txtcrawlState))
                                {
                                    AskForTextCrawlEnaDis(l_txtcrawlEna);
                                    main();
                                }
                            }
                        }
                      
                        else if(btn_textcrawl.Text == "OFF TEXT CRAWL")
                        {
                            txtcrawlState = sdr["status_off"].ToString();
                            l_txtcrawlEna = Int32.Parse(sdr["trigg_dis"].ToString());

                            s_c_trigger_status = txtcrawlState;

                            if (AskForLogoAssetID(ass_ID))
                            {
                                if (AskForTextCrawlStatus(txtcrawlState))
                                {
                                    AskForTextCrawlEnaDis(l_txtcrawlEna);
                                    main();
                                }
                            }
                        }

                        
                    }

                    conn.Close();
                }
                catch (Exception ex)
                {

                }
            }
        }
        private void sec_playout()
        {
            if(comboBox_Playout.SelectedIndex>-1 && sec_module == 3 )
            {
                try
                {
                    conn.Open();
                   NpgsqlCommand cmd = new NpgsqlCommand("select  = '" + comboBox_Playout.SelectedItem.ToString() + "'AND resolution = '" + resolution + "'", conn);
                    NpgsqlDataReader sdr = cmd.ExecuteReader();
                    if (sdr.Read())
                    {
                        string ass_ID = sdr["asset_id"].ToString();
                        string playoutState;
                        int l_lPlayoutEna;

                        
                        p_duration = (Int32.Parse(sdr["length"].ToString())+8); 

                        if (btn_playout.Text == "ON PLAYOUT")
                        {
                             playoutState = sdr["status_on"].ToString();
                             l_lPlayoutEna = Int32.Parse(sdr["trigger_ena"].ToString());

                            s_c_trigger_status = playoutState;

                            if (AskForLogoAssetID(ass_ID))
                            {
                                if (AskForPlayoutStatus(playoutState))
                                {

                                    AskForPlayoutEnaDis(l_lPlayoutEna);
                                    main();
                                }
                            }
                        }
                        else if(btn_playout.Text == "OFF PLAYOUT")
                        {
                            playoutState = sdr["status_off"].ToString();
                            l_lPlayoutEna = Int32.Parse(sdr["trigg_dis"].ToString());

                            s_c_trigger_status = playoutState;

                            if (AskForLogoAssetID(ass_ID))
                            {
                                if (AskForPlayoutStatus(playoutState))
                                {

                                    AskForPlayoutEnaDis(l_lPlayoutEna);
                                    main();
                                }
                            }
                        }

                       
                    }
                    conn.Close();
                }
                catch(Exception ex)
                {

                }
            }
        }
        private void db_batch_ID()
        {
            try
            {
                conn.Open();
                NpgsqlCommand cmd = new NpgsqlCommand("select  ORDER BY id DESC LIMIT 1", conn);
                NpgsqlDataReader sdr = cmd.ExecuteReader();
                if(sdr.Read())
                {
                    s_db_batch_id = (Int32.Parse(sdr["batch_id"].ToString()))+1;
                    s_c_primID = Int32.Parse(sdr["id"].ToString());
                }
                conn.Close();
            }
            catch(Exception ex)
            {
                MetroMessageBox.Show(this,""+ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }
        private void managedata_batch_used(String qry)
        {
            

                try
                {

                    conn.Open();
                    NpgsqlCommand cmd = new NpgsqlCommand(qry, conn);
                  
                    cmd.Parameters.Add("batch_id", NpgsqlTypes.NpgsqlDbType.Integer).Value = s_batchID;
                    cmd.Parameters.Add("channel_name", NpgsqlTypes.NpgsqlDbType.Varchar).Value = s_c_name;
                    cmd.Parameters.Add("module", NpgsqlTypes.NpgsqlDbType.Varchar).Value = s_c_module;
                    cmd.Parameters.Add("trigger_status", NpgsqlTypes.NpgsqlDbType.Varchar).Value = s_c_trigger_status;
                    
                    cmd.ExecuteNonQuery();
                    conn.Close();

            }
            catch (Exception ex)
                {
                    MetroMessageBox.Show(this, "Error:    " + ex.Message.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

            
         
        }
        
        private void btnlogo_Click_1(object sender, EventArgs e)
        {
            sec_module = 1;
           
            hOffset = Int32.Parse(txtbox_hOfsset.Text);
            vOffset = Int32.Parse(txtbox_vOffset.Text);

            btnlogo.BackColor = Color.Blue;
            btn_textcrawl.Enabled = false;
            btn_playout.Enabled = false;
        
        }

        private void btn_textcrawl_Click(object sender, EventArgs e)
        {
            btn_textcrawl.BackColor = Color.Blue;
            btn_playout.Enabled = false;
            btnlogo.Enabled = false;

            sec_module = 2;
        }

        private void btn_playout_Click(object sender, EventArgs e)
        {
            btn_auto_start_end.Enabled = true;
            btn_playout.BackColor = Color.Blue;
            btn_textcrawl.Enabled = false;
            btnlogo.Enabled = false;

            sec_module = 3;
        }

        private void radioButton_TL_PNG_CheckedChanged(object sender, EventArgs e)
        {
            pos = 1;
        }

        private void radioButton_TR_PNG_CheckedChanged(object sender, EventArgs e)
        {
            pos = 2;
        }

        private void radioButton_BL_PNG_CheckedChanged(object sender, EventArgs e)
        {
            pos = 3;
        }

        private void radioButton_BR_PNG_CheckedChanged(object sender, EventArgs e)
        {
            pos = 4;
        }

        private void metroPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_close_selected_chan_Click(object sender, EventArgs e)
        {
            panel_file_list.Hide();

            btnlogo.Enabled = true;
            btn_textcrawl.Enabled = true;
            btn_playout.Enabled = true;

            btnlogo.BackColor = Color.Lime;
            btn_textcrawl.BackColor = Color.Lime;
            btn_playout.BackColor = Color.Lime;

            
            comboBox_Logo.Items.Clear();
            comboBox_Textcrawl.Items.Clear();
            comboBox_Playout.Items.Clear();
            listBox_selected_Channels.Items.Clear();

          
            radioButton_TL_PNG.Checked = false;
            radioButton_TR_PNG.Checked = false;
            radioButton_BL_PNG.Checked = false;
            radioButton_BR_PNG.Checked = false;
            radioButton_rSD.Checked = false;
            radioButton_TR_PNG.Checked = false;
        }

        private void btn_close_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_close_MouseHover(object sender, EventArgs e)
        {
            btn_close.BackColor = Color.Red;
        }

        private void timer_playout_length_Tick(object sender, EventArgs e)
        {
            if (_isPlayout_timer)
            {
                playout_length++;
                lbl_playout.Text = playout_length.ToString();
                stop_Playout();
                if (aa == 1)
                {
                    playout_length = 0;
                    ResetTime_Playout();
                }

            }
        }
        private void ResetTime_Playout()
        {
            playout_length = 0;
            _isPlayout_timer = false;
            timer_playout_length.Stop();

        }

        private void btn_playout_MouseHover(object sender, EventArgs e)
        {
            btn_playout.BackColor = Color.FromArgb(0, 192, 0);
        }

        private void btn_playout_MouseLeave(object sender, EventArgs e)
        {
            btn_playout.BackColor = Color.Lime;
        }

        private void btn_textcrawl_MouseHover(object sender, EventArgs e)
        {
            btn_textcrawl.BackColor = Color.FromArgb(0, 192, 0);
        }

        private void btn_textcrawl_MouseLeave(object sender, EventArgs e)
        {
            btn_textcrawl.BackColor = Color.Lime;
        }

        private void btnlogo_MouseHover(object sender, EventArgs e)
        {
            btnlogo.BackColor = Color.FromArgb(0, 192, 0);
        }

        private void btnlogo_MouseLeave(object sender, EventArgs e)
        {
            btnlogo.BackColor = Color.Lime;
        }

        private void btn_submit_MouseHover(object sender, EventArgs e)
        {
            btn_submit.BackColor = Color.FromArgb(0,192,0);
        }

        private void btn_submit_MouseLeave(object sender, EventArgs e)
        {
            btn_submit.BackColor = Color.Lime;
        }

        private void btn_auto_start_end_MouseHover(object sender, EventArgs e)
        {
            if(btn_auto_start_end.Enabled == true)
            {
                btn_auto_start_end.BackColor = Color.FromArgb(0,192,0);
            }
        }

        private void btn_auto_start_end_MouseLeave(object sender, EventArgs e)
        {
            if (btn_auto_start_end.Enabled == true)
            {
                btn_auto_start_end.BackColor = Color.Lime;
            }
        }

       
        private void toolStripMenuItem_Ena_MouseLeave(object sender, EventArgs e)
        {
           
        }
        private void toolStripMenuItem_Ena_MouseHover(object sender,EventArgs e)
        {
            
        }

        private void txtbox_sched_min_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            int dig_max = 1; 
            
            if (char.IsPunctuation(ch) == true || char.IsSymbol(ch) == true || char.IsLetter(ch) == true)
            {
                txtbox_sched_min.Clear();
            }
            else
            {
               
            }
            if (txtbox_sched_min.Text.Length >dig_max)
            {
                txtbox_sched_min.Clear();
            }
            else
            {
               
            }
            

        }

        private void txtbox_sched_sec_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            int dig_max = 1;
            int t_max = 60;
            if (char.IsPunctuation(ch) == true || char.IsSymbol(ch) == true || char.IsLetter(ch) == true)
            {
                txtbox_sched_sec.Clear();
            }
            else
            {
               
            }
            if(txtbox_sched_sec.Text.Length>dig_max)
            {
                txtbox_sched_sec.Clear();
            }
            else
            {
                //do nothing
            }

        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            Reload_Form_GUI();
        }
        private void Reload_Form_GUI() 
        {
            
            btnlogo.Refresh();
            btn_textcrawl.Refresh();
            btn_playout.Refresh();

            btn_submit.Refresh();
            btn_auto_start_end.Refresh();

            btnlogo.Enabled = true;
            btn_textcrawl.Enabled = true;
            btn_playout.Enabled = true;

           
          
           
            ResetTime();
            timer_playout_length.Stop();

            txtbox_sched_min.Clear();
            txtbox_sched_sec.Clear();


           

           
            CHANNELS.Update();
            CHANNELS.Refresh();

            lbl_start_end.Hide();

            //refresh main panel cover
            metroPanel1.Refresh();


        }

        private void btn_hide_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

      
        private void stop_Playout()
        {
           
                    if (playout_length == p_duration)
                    {

                       
                        
                        lbl_start_end.Visible = true;
                        lbl_start_end.ForeColor = Color.Red;
                        lbl_start_end.Text = "STOP!";
                        end_auto_playout();
                        aa = 1;

                    }
           
        }
        private void end_auto_playout() 
        {
          

          
            if (sec_module == 1)
            {
                btnlogo.Text = "OFF LOGO";
                if (listBox_selected_Channels.Items.Count > 0)
                {
                    db_batch_ID();

                    s_cout_Chan = listBox_selected_Channels.Items.Count;
                                                                        
                    get_IP();
                    get_default_NMX_specs();
                    s_cntrl_type(); 
                                  

                    //--- reset here    
                    listBox_selected_Channels.Items.Clear();
                    panel_file_list.Hide();

                    btnlogo.Enabled = true;
                    btn_textcrawl.Enabled = true;
                    btn_playout.Enabled = true;

                    btnlogo.BackColor = Color.Lime;
                    btn_textcrawl.BackColor = Color.Lime;
                    btn_playout.BackColor = Color.Lime;
                    //---------------

                }
            }
            else if (sec_module == 2)
            {
                btn_textcrawl.Text = "OFF TEXT CRAWL";
                if (listBox_selected_Channels.Items.Count > 0)
                {
                    db_batch_ID();

                    s_cout_Chan = listBox_selected_Channels.Items.Count;
                                                                       
                    get_IP();
                    get_default_NMX_specs();
                    s_cntrl_type(); // st

                    //--- reset here    
                    listBox_selected_Channels.Items.Clear(); // reset here
                    panel_file_list.Hide();

                    btnlogo.Enabled = true;
                    btn_textcrawl.Enabled = true;
                    btn_playout.Enabled = true;


                }
            }
            else if (sec_module == 3)
            {
                btn_playout.Text = "OFF PLAYOUT";
                if (listBox_selected_Channels.Items.Count > 0)
                {
                    db_batch_ID();

                    s_cout_Chan = listBox_selected_Channels.Items.Count;
                    get_IP();
                    get_default_NMX_specs();
                    s_cntrl_type(); 
                                   
                    listBox_selected_Channels.Items.Clear();
                    panel_file_list.Hide();

                    btnlogo.Enabled = true;
                    btn_textcrawl.Enabled = true;
                    btn_playout.Enabled = true;

                    btnlogo.BackColor = Color.Lime;
                    btn_textcrawl.BackColor = Color.Lime;
                    btn_playout.BackColor = Color.Lime;
                    

                }
            }




        }
        private void timer_s_Tick(object sender, EventArgs e)
        {
            if (_isActive)
            {
                t_miliSec++;
                if (t_val == 1)
                {
                    if (t_min == Int32.Parse(txtbox_sched_min.Text) && t_sec == Int32.Parse(txtbox_sched_sec.Text))
                    {
                        t_val = 4;
                        ResetTime();


                       
                        timer_playout_length.Start();
                        _isPlayout_timer = true;
                    }
                    else
                    {
                        //do nothing
                    }

                }

                else if (t_val == 2)
                {
                    if (t_min == Int32.Parse(txtbox_sched_min.Text) && txtbox_sched_sec.Text == string.Empty)
                    {
                        t_val = 5;
                        ResetTime();

                        timer_playout_length.Enabled = true;
                        timer_playout_length.Start();
                        _isPlayout_timer = true;
                    }
                    else
                    {
                        //do nothing
                    }
                }
                else if (t_val == 3)
                {
                    if (txtbox_sched_min.Text == string.Empty && t_sec == Int32.Parse(txtbox_sched_sec.Text))
                    {
                        t_val = 6;
                        ResetTime();

                        timer_playout_length.Enabled = true;
                        timer_playout_length.Start();
                        _isPlayout_timer = true;
                    }
                    else
                    {
                        //do nothing
                    }
                }

              
                if (t_miliSec >= 30)
                {
                    t_sec++;
                    t_miliSec = 0;
                    if (t_sec == 60)
                    {
                        t_min++;
                        t_sec = 0;

                        if (t_min == 60)
                        {
                            t_min = 0;
                            ResetTime();
                        }
                    }
                }
            }
            _Elaps_Time();


        }
        private void ResetTime()
        {
            t_min = 0;
            t_sec = 0;
            t_miliSec = 0;

            playout_length = 0;//playout time reset

            timer_s.Stop();
        }
        private void _Elaps_Time()
        {
            lbl_mili_sec.Text = string.Format("{0:00}", t_miliSec);
            lbl_sec.Text = string.Format("{0:00}", t_sec);
            lbl_min.Text = string.Format("{0:00}", t_min);

            //progressbar await show count
            lbl_pbar_await_min.Text = lbl_min.Text;
            lbl_pbar_await_sec.Text = lbl_sec.Text;
            

            if (t_val == 4)
            {
                start_auto_playout();//start Playout ON automatic
                lbl_start_end.Visible = true;
                lbl_start_end.ForeColor = Color.Green;
            }
            else if (t_val == 5)
            {
                start_auto_playout();//start Playout ON automatic
                lbl_start_end.Visible = true;
                lbl_start_end.ForeColor = Color.Green;
            }
            else if (t_val == 6)
            {
                start_auto_playout();//start Playout ON automatic
                lbl_start_end.Visible = true;
                lbl_start_end.ForeColor = Color.Green;
            }
        }
        
        private void timer_date_time_Tick(object sender, EventArgs e)
        {
            int t = 0;
            t++;
            timer_date_time.Enabled = true;
            
            if(t>0)
            {
                timer_date_time.Start();
                lbl_time.Text = DateTime.Now.ToLongTimeString();
            }
          
        }

        private void btn_auto_start_end_Click(object sender, EventArgs e)
        {

            if (txtbox_sched_min.Text == "" && txtbox_sched_sec.Text == "")
            {
                MetroMessageBox.Show(this, "Double your input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
            else if(txtbox_sched_min.Text != "" && txtbox_sched_sec.Text == "")
            {
                MetroMessageBox.Show(this, "Double your input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if(txtbox_sched_min.Text == "" && txtbox_sched_sec.Text != "")
            {
                MetroMessageBox.Show(this, "Double your input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
               
                int t_max_val = 60;
                int get_min_val = Int32.Parse(txtbox_sched_min.Text);
                int get_sec_val = Int32.Parse(txtbox_sched_sec.Text);
                int _error;

                if(get_min_val>t_max_val && get_sec_val>t_max_val)
                {
                    MetroMessageBox.Show(this,"Double your input","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    _error = 1;
                }
                else if(get_min_val > t_max_val && get_sec_val <= t_max_val)
                {
                    MetroMessageBox.Show(this, "Double your input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    _error = 1;
                }
                else if(get_min_val <= t_max_val && get_sec_val >t_max_val)
                {
                    MetroMessageBox.Show(this, "Double your input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    _error = 1;
                }
                else
                {
                    _error = 0;
                }


                if (_error != 0)
                {
                    //do nothing
                }
                else
                {
                   
                    if (btn_auto_start_end.Text == "SET TIME")
                    {
                        if (CHANNELS.CheckedItems.Count > 0)
                        {
                            foreach (var s_item in CHANNELS.CheckedItems)
                            {
                                listBox_selected_Channels.Items.Add(s_item.ToString());
                              

                            }
                            panel_file_list.Show();
                            set_time = 1;
                        }
                    }
                }
            }
           

        }
        
        private void start_auto_playout()
        {

           
            groupBox_progressbar.Hide();


           
            if (listBox_selected_Channels.Items.Count > 0)
            {
                db_batch_ID();

                s_cout_Chan = listBox_selected_Channels.Items.Count;
                                                                   
                get_IP();
                get_default_NMX_specs();
                s_cntrl_type(); 
                panel_file_list.Hide();

                btnlogo.Enabled = true;
                btn_textcrawl.Enabled = true;
                btn_playout.Enabled = true;

                btnlogo.BackColor = Color.Lime;
                btn_textcrawl.BackColor = Color.Lime;
                btn_playout.BackColor = Color.Lime;
                //---------------

            }


        }
       
       

        private void pictureBox_enadis_Click(object sender, EventArgs e)
        {
            contextMenuStrip_EnaDis.Show(pictureBox_enadis,0,pictureBox_enadis.Height);
        }

        private void pictureBox_enadis_MouseHover(object sender, EventArgs e)
        {
            panel_enadis_menustrip.BackColor = Color.FromArgb(0,192,0);
        }

        private void pictureBox_enadis_MouseLeave(object sender, EventArgs e)
        {
            panel_enadis_menustrip.BackColor = Color.White;
        }

      

        private void toolStripMenuItem_Dis_Click(object sender, EventArgs e)
        {
            label_ENA_DIS.Text = "DISABLE";
            btnlogo.Text = "OFF LOGO";
            btn_textcrawl.Text = "OFF TEXT CRAWL";
            btn_playout.Text = "OFF PLAYOUT";
        }

        private void toolStripMenuItem_Ena_Click(object sender, EventArgs e)
        {
            label_ENA_DIS.Text = "ENABLE";
            btnlogo.Text = "ON LOGO";
            btn_textcrawl.Text = "ON TEXT CRAWL";
            btn_playout.Text = "ON PLAYOUT";
        }

       

     

        private void radioButton_rHD_CheckedChanged_1(object sender, EventArgs e)
        {
               
                if (sec_module == 3)
                {

                    if (radioButton_rHD.Checked == true)
                    {
                    resolution = "HD";
                    try
                        {
                            conn.Open();
                            


                            NpgsqlCommand cmd_playout = new NpgsqlCommand("select  = 'HD'", conn);
                            NpgsqlDataReader sdr_playout = cmd_playout.ExecuteReader();
                            while (sdr_playout.Read())
                            {
                                string playout = sdr_playout.GetValue(0).ToString();

                               
                                comboBox_Playout.Items.Add(playout);
                            }

                            conn.Close();
                        }
                        catch (Exception ex)
                        {
                            MetroMessageBox.Show(this, "Error:    " + ex.Message.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }

                    }
                    else
                    {
                       
                        comboBox_Playout.Items.Clear();
                  
                    }
                }
                else if (sec_module == 2)
                {
                    if (radioButton_rHD.Checked == true)
                    {
                    resolution = "HD";
                    try
                        {

                            conn.Open();
                            //getdate from_db

                            NpgsqlCommand cmd_textcrawl = new NpgsqlCommand("select 'HD'", conn);
                            NpgsqlDataReader sdr_textcrawl = cmd_textcrawl.ExecuteReader();
                            while (sdr_textcrawl.Read())
                            {
                                string textcrawl = sdr_textcrawl.GetValue(0).ToString();

                                comboBox_Textcrawl.Items.Add(textcrawl);
                            }


                            conn.Close();

                        }
                        catch (Exception ex)
                        {
                            MetroMessageBox.Show(this, "Error:    " + ex.Message.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                       
                        comboBox_Textcrawl.Items.Clear();
                    }
                }
                else if (sec_module == 1)
                {
                    if (radioButton_rHD.Checked == true)
                    {
                    resolution = "HD";
                    try
                        {

                            conn.Open();


                           
                            NpgsqlCommand cmd_logo = new NpgsqlCommand("select 'HD'", conn);
                            NpgsqlDataReader sdr_logo = cmd_logo.ExecuteReader();
                            while (sdr_logo.Read())
                            {
                                string logo = sdr_logo.GetValue(0).ToString();
                                
                                comboBox_Logo.Items.Add(logo);

                            }


                            conn.Close();

                        }
                        catch (Exception ex)
                        {
                            MetroMessageBox.Show(this, "Error:    " + ex.Message.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    else
                    {
                       
                        comboBox_Logo.Items.Clear();
                    }
                }
            

        }

       
        private void btn_close_MouseHover_1(object sender, EventArgs e)
        {
            btn_close.BackColor = Color.Red;
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
