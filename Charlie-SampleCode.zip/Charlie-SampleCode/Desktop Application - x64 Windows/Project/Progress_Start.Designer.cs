﻿namespace GUI
{
    partial class Progress_Start
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbllaodpercent = new System.Windows.Forms.Label();
            this.lblloading = new System.Windows.Forms.Label();
            this.metroProgressBar1 = new MetroFramework.Controls.MetroProgressBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // lbllaodpercent
            // 
            this.lbllaodpercent.AutoSize = true;
            this.lbllaodpercent.BackColor = System.Drawing.Color.Transparent;
            this.lbllaodpercent.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllaodpercent.ForeColor = System.Drawing.Color.White;
            this.lbllaodpercent.Location = new System.Drawing.Point(343, 206);
            this.lbllaodpercent.Name = "lbllaodpercent";
            this.lbllaodpercent.Size = new System.Drawing.Size(27, 13);
            this.lbllaodpercent.TabIndex = 5;
            this.lbllaodpercent.Text = "10%";
            this.lbllaodpercent.Click += new System.EventHandler(this.lbllaodpercent_Click);
            // 
            // lblloading
            // 
            this.lblloading.AutoSize = true;
            this.lblloading.BackColor = System.Drawing.Color.Transparent;
            this.lblloading.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblloading.ForeColor = System.Drawing.Color.White;
            this.lblloading.Location = new System.Drawing.Point(55, 206);
            this.lblloading.Name = "lblloading";
            this.lblloading.Size = new System.Drawing.Size(152, 13);
            this.lblloading.TabIndex = 4;
            this.lblloading.Text = "Wait untill to finish the load . . .";
            this.lblloading.Click += new System.EventHandler(this.lblloading_Click);
            // 
            // metroProgressBar1
            // 
            this.metroProgressBar1.Location = new System.Drawing.Point(57, 200);
            this.metroProgressBar1.Name = "metroProgressBar1";
            this.metroProgressBar1.Size = new System.Drawing.Size(313, 5);
            this.metroProgressBar1.Style = MetroFramework.MetroColorStyle.Green;
            this.metroProgressBar1.TabIndex = 3;
            this.metroProgressBar1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroProgressBar1.UseCustomBackColor = true;
            this.metroProgressBar1.Click += new System.EventHandler(this.metroProgressBar1_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Progress_Start
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::GUI.Properties.Resources.maxresdefault;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(439, 218);
            this.Controls.Add(this.lbllaodpercent);
            this.Controls.Add(this.lblloading);
            this.Controls.Add(this.metroProgressBar1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Progress_Start";
            this.Text = "Progress_Start";
            this.Load += new System.EventHandler(this.Progress_Start_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbllaodpercent;
        private System.Windows.Forms.Label lblloading;
        private MetroFramework.Controls.MetroProgressBar metroProgressBar1;
        private System.Windows.Forms.Timer timer1;
    }
}