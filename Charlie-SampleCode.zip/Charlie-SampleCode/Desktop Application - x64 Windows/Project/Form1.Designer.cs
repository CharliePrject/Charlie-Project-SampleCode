﻿namespace GUI
{
    partial class GUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.metroPanel3 = new MetroFramework.Controls.MetroPanel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox_progressbar = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.lbl_pbar_await_min = new System.Windows.Forms.Label();
            this.lbl_pbar_await_sec = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.panel_file_list = new System.Windows.Forms.Panel();
            this.btn_proceed = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.btn_close_selected_chan = new System.Windows.Forms.Button();
            this.listBox_selected_Channels = new System.Windows.Forms.ListBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox_Scheduling = new System.Windows.Forms.GroupBox();
            this.lbl_start_end = new System.Windows.Forms.Label();
            this.lbl_playout = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtbox_sched_sec = new System.Windows.Forms.TextBox();
            this.lbl_mili_sec = new System.Windows.Forms.Label();
            this.txtbox_sched_min = new System.Windows.Forms.TextBox();
            this.lbl_sec = new System.Windows.Forms.Label();
            this.lbl_min = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.btn_auto_start_end = new System.Windows.Forms.Button();
            this.btn_submit = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.comboBox_Playout = new MetroFramework.Controls.MetroComboBox();
            this.comboBox_Textcrawl = new MetroFramework.Controls.MetroComboBox();
            this.comboBox_Logo = new MetroFramework.Controls.MetroComboBox();
            this.radioButton_rSD = new System.Windows.Forms.RadioButton();
            this.radioButton_rHD = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.radioButton_BR_PNG = new System.Windows.Forms.RadioButton();
            this.radioButton_BL_PNG = new System.Windows.Forms.RadioButton();
            this.radioButton_TR_PNG = new System.Windows.Forms.RadioButton();
            this.radioButton_TL_PNG = new System.Windows.Forms.RadioButton();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.CHANNELS = new System.Windows.Forms.ListView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbl_time = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lbl_date = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_playout = new System.Windows.Forms.Button();
            this.btn_textcrawl = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel_enadis_menustrip = new System.Windows.Forms.Panel();
            this.pictureBox_enadis = new System.Windows.Forms.PictureBox();
            this.label_ENA_DIS = new System.Windows.Forms.Label();
            this.btnlogo = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.metroPanel2 = new MetroFramework.Controls.MetroPanel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btn_hide = new System.Windows.Forms.Button();
            this.btn_refresh = new System.Windows.Forms.Button();
            this.btn_close = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.contextMenuStrip_EnaDis = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem_Ena = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem_Dis = new System.Windows.Forms.ToolStripMenuItem();
            this.timer_date_time = new System.Windows.Forms.Timer(this.components);
            this.timer_playout_length = new System.Windows.Forms.Timer(this.components);
            this.timer_s = new System.Windows.Forms.Timer(this.components);
            this.txtbox_vOffset = new System.Windows.Forms.TextBox();
            this.txtbox_hOfsset = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.metroPanel1.SuspendLayout();
            this.metroPanel3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox_progressbar.SuspendLayout();
            this.panel_file_list.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox_Scheduling.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel_enadis_menustrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_enadis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.metroPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.contextMenuStrip_EnaDis.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroPanel1.BackColor = System.Drawing.Color.Transparent;
            this.metroPanel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.metroPanel1.Controls.Add(this.metroPanel3);
            this.metroPanel1.Controls.Add(this.metroPanel2);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(5, 4);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(1347, 711);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.UseCustomBackColor = true;
            this.metroPanel1.UseCustomForeColor = true;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            this.metroPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.metroPanel1_Paint);
            // 
            // metroPanel3
            // 
            this.metroPanel3.BackColor = System.Drawing.Color.Transparent;
            this.metroPanel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.metroPanel3.Controls.Add(this.groupBox4);
            this.metroPanel3.Controls.Add(this.groupBox1);
            this.metroPanel3.HorizontalScrollbarBarColor = true;
            this.metroPanel3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel3.HorizontalScrollbarSize = 10;
            this.metroPanel3.Location = new System.Drawing.Point(5, 34);
            this.metroPanel3.Name = "metroPanel3";
            this.metroPanel3.Size = new System.Drawing.Size(1332, 670);
            this.metroPanel3.TabIndex = 3;
            this.metroPanel3.UseCustomBackColor = true;
            this.metroPanel3.UseCustomForeColor = true;
            this.metroPanel3.VerticalScrollbarBarColor = true;
            this.metroPanel3.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel3.VerticalScrollbarSize = 10;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.groupBox4.Controls.Add(this.groupBox_progressbar);
            this.groupBox4.Controls.Add(this.panel_file_list);
            this.groupBox4.Controls.Add(this.panel4);
            this.groupBox4.Controls.Add(this.CHANNELS);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.White;
            this.groupBox4.Location = new System.Drawing.Point(261, 14);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1064, 526);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "CHANNEL SERVICES ON AIR";
            // 
            // groupBox_progressbar
            // 
            this.groupBox_progressbar.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox_progressbar.BackgroundImage = global::GUI.Properties.Resources._1155040;
            this.groupBox_progressbar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox_progressbar.Controls.Add(this.label16);
            this.groupBox_progressbar.Controls.Add(this.lbl_pbar_await_min);
            this.groupBox_progressbar.Controls.Add(this.lbl_pbar_await_sec);
            this.groupBox_progressbar.Controls.Add(this.progressBar1);
            this.groupBox_progressbar.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_progressbar.ForeColor = System.Drawing.Color.White;
            this.groupBox_progressbar.Location = new System.Drawing.Point(193, 226);
            this.groupBox_progressbar.Name = "groupBox_progressbar";
            this.groupBox_progressbar.Size = new System.Drawing.Size(398, 42);
            this.groupBox_progressbar.TabIndex = 26;
            this.groupBox_progressbar.TabStop = false;
            this.groupBox_progressbar.Text = "Scheduling . . .";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(109, 4);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(7, 10);
            this.label16.TabIndex = 29;
            this.label16.Text = ":";
            // 
            // lbl_pbar_await_min
            // 
            this.lbl_pbar_await_min.AutoSize = true;
            this.lbl_pbar_await_min.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pbar_await_min.Location = new System.Drawing.Point(93, 3);
            this.lbl_pbar_await_min.Name = "lbl_pbar_await_min";
            this.lbl_pbar_await_min.Size = new System.Drawing.Size(17, 12);
            this.lbl_pbar_await_min.TabIndex = 28;
            this.lbl_pbar_await_min.Text = "00";
            // 
            // lbl_pbar_await_sec
            // 
            this.lbl_pbar_await_sec.AutoSize = true;
            this.lbl_pbar_await_sec.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pbar_await_sec.Location = new System.Drawing.Point(115, 3);
            this.lbl_pbar_await_sec.Name = "lbl_pbar_await_sec";
            this.lbl_pbar_await_sec.Size = new System.Drawing.Size(17, 12);
            this.lbl_pbar_await_sec.TabIndex = 27;
            this.lbl_pbar_await_sec.Text = "00";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(12, 21);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(374, 10);
            this.progressBar1.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.progressBar1.TabIndex = 24;
            // 
            // panel_file_list
            // 
            this.panel_file_list.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.panel_file_list.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_file_list.Controls.Add(this.btn_proceed);
            this.panel_file_list.Controls.Add(this.panel6);
            this.panel_file_list.Controls.Add(this.listBox_selected_Channels);
            this.panel_file_list.Location = new System.Drawing.Point(251, 154);
            this.panel_file_list.Name = "panel_file_list";
            this.panel_file_list.Size = new System.Drawing.Size(403, 225);
            this.panel_file_list.TabIndex = 4;
            // 
            // btn_proceed
            // 
            this.btn_proceed.BackColor = System.Drawing.Color.Lime;
            this.btn_proceed.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_proceed.Location = new System.Drawing.Point(295, 194);
            this.btn_proceed.Name = "btn_proceed";
            this.btn_proceed.Size = new System.Drawing.Size(102, 25);
            this.btn_proceed.TabIndex = 5;
            this.btn_proceed.Text = "PROCEED";
            this.btn_proceed.UseVisualStyleBackColor = false;
            this.btn_proceed.Click += new System.EventHandler(this.btn_proceed_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.label9);
            this.panel6.Controls.Add(this.btn_close_selected_chan);
            this.panel6.Location = new System.Drawing.Point(-1, -1);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(401, 31);
            this.panel6.TabIndex = 14;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(6, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(169, 22);
            this.label9.TabIndex = 20;
            this.label9.Text = "SELECTED CHANNELS";
            // 
            // btn_close_selected_chan
            // 
            this.btn_close_selected_chan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_close_selected_chan.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close_selected_chan.ForeColor = System.Drawing.Color.White;
            this.btn_close_selected_chan.Location = new System.Drawing.Point(358, 4);
            this.btn_close_selected_chan.Name = "btn_close_selected_chan";
            this.btn_close_selected_chan.Size = new System.Drawing.Size(34, 24);
            this.btn_close_selected_chan.TabIndex = 4;
            this.btn_close_selected_chan.Text = "X";
            this.btn_close_selected_chan.UseVisualStyleBackColor = false;
            this.btn_close_selected_chan.Click += new System.EventHandler(this.btn_close_selected_chan_Click);
            this.btn_close_selected_chan.MouseLeave += new System.EventHandler(this.btn_close_selected_chan_MouseLeave);
            this.btn_close_selected_chan.MouseHover += new System.EventHandler(this.btn_close_selected_chan_MouseHover);
            // 
            // listBox_selected_Channels
            // 
            this.listBox_selected_Channels.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.listBox_selected_Channels.ForeColor = System.Drawing.Color.White;
            this.listBox_selected_Channels.FormattingEnabled = true;
            this.listBox_selected_Channels.Location = new System.Drawing.Point(3, 32);
            this.listBox_selected_Channels.Name = "listBox_selected_Channels";
            this.listBox_selected_Channels.Size = new System.Drawing.Size(394, 160);
            this.listBox_selected_Channels.TabIndex = 13;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.groupBox5);
            this.panel4.Location = new System.Drawing.Point(762, 19);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(296, 501);
            this.panel4.TabIndex = 1;
            // 
            // groupBox5
            // 
            this.groupBox5.BackgroundImage = global::GUI.Properties.Resources._1155040;
            this.groupBox5.Controls.Add(this.groupBox_Scheduling);
            this.groupBox5.Controls.Add(this.btn_auto_start_end);
            this.groupBox5.Controls.Add(this.btn_submit);
            this.groupBox5.Controls.Add(this.groupBox7);
            this.groupBox5.Controls.Add(this.groupBox6);
            this.groupBox5.Controls.Add(this.panel5);
            this.groupBox5.Location = new System.Drawing.Point(3, 3);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(290, 495);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            // 
            // groupBox_Scheduling
            // 
            this.groupBox_Scheduling.BackColor = System.Drawing.Color.Transparent;
            this.groupBox_Scheduling.Controls.Add(this.lbl_start_end);
            this.groupBox_Scheduling.Controls.Add(this.lbl_playout);
            this.groupBox_Scheduling.Controls.Add(this.label21);
            this.groupBox_Scheduling.Controls.Add(this.label23);
            this.groupBox_Scheduling.Controls.Add(this.label20);
            this.groupBox_Scheduling.Controls.Add(this.txtbox_sched_sec);
            this.groupBox_Scheduling.Controls.Add(this.lbl_mili_sec);
            this.groupBox_Scheduling.Controls.Add(this.txtbox_sched_min);
            this.groupBox_Scheduling.Controls.Add(this.lbl_sec);
            this.groupBox_Scheduling.Controls.Add(this.lbl_min);
            this.groupBox_Scheduling.Controls.Add(this.label13);
            this.groupBox_Scheduling.Controls.Add(this.label10);
            this.groupBox_Scheduling.Controls.Add(this.label8);
            this.groupBox_Scheduling.ForeColor = System.Drawing.Color.White;
            this.groupBox_Scheduling.Location = new System.Drawing.Point(16, 325);
            this.groupBox_Scheduling.Name = "groupBox_Scheduling";
            this.groupBox_Scheduling.Size = new System.Drawing.Size(259, 94);
            this.groupBox_Scheduling.TabIndex = 6;
            this.groupBox_Scheduling.TabStop = false;
            this.groupBox_Scheduling.Text = "Set Auto";
            // 
            // lbl_start_end
            // 
            this.lbl_start_end.AutoSize = true;
            this.lbl_start_end.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_start_end.Location = new System.Drawing.Point(113, 68);
            this.lbl_start_end.Name = "lbl_start_end";
            this.lbl_start_end.Size = new System.Drawing.Size(59, 19);
            this.lbl_start_end.TabIndex = 24;
            this.lbl_start_end.Text = "START";
            // 
            // lbl_playout
            // 
            this.lbl_playout.AutoSize = true;
            this.lbl_playout.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_playout.Location = new System.Drawing.Point(103, 8);
            this.lbl_playout.Name = "lbl_playout";
            this.lbl_playout.Size = new System.Drawing.Size(17, 12);
            this.lbl_playout.TabIndex = 30;
            this.lbl_playout.Text = "00";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(134, 22);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(10, 13);
            this.label21.TabIndex = 28;
            this.label21.Text = ":";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(165, 20);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(8, 12);
            this.label23.TabIndex = 29;
            this.label23.Text = ".";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(134, 10);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(10, 13);
            this.label20.TabIndex = 27;
            this.label20.Text = ":";
            // 
            // txtbox_sched_sec
            // 
            this.txtbox_sched_sec.Location = new System.Drawing.Point(154, 34);
            this.txtbox_sched_sec.Multiline = true;
            this.txtbox_sched_sec.Name = "txtbox_sched_sec";
            this.txtbox_sched_sec.Size = new System.Drawing.Size(40, 23);
            this.txtbox_sched_sec.TabIndex = 22;
            this.txtbox_sched_sec.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbox_sched_sec_KeyPress);
            // 
            // lbl_mili_sec
            // 
            this.lbl_mili_sec.AutoSize = true;
            this.lbl_mili_sec.Font = new System.Drawing.Font("Cambria", 6F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mili_sec.Location = new System.Drawing.Point(171, 22);
            this.lbl_mili_sec.Name = "lbl_mili_sec";
            this.lbl_mili_sec.Size = new System.Drawing.Size(15, 10);
            this.lbl_mili_sec.TabIndex = 27;
            this.lbl_mili_sec.Text = "00";
            // 
            // txtbox_sched_min
            // 
            this.txtbox_sched_min.Location = new System.Drawing.Point(80, 34);
            this.txtbox_sched_min.Multiline = true;
            this.txtbox_sched_min.Name = "txtbox_sched_min";
            this.txtbox_sched_min.Size = new System.Drawing.Size(40, 23);
            this.txtbox_sched_min.TabIndex = 21;
            this.txtbox_sched_min.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbox_sched_min_KeyPress);
            // 
            // lbl_sec
            // 
            this.lbl_sec.AutoSize = true;
            this.lbl_sec.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sec.Location = new System.Drawing.Point(152, 20);
            this.lbl_sec.Name = "lbl_sec";
            this.lbl_sec.Size = new System.Drawing.Size(17, 12);
            this.lbl_sec.TabIndex = 26;
            this.lbl_sec.Text = "00";
            // 
            // lbl_min
            // 
            this.lbl_min.AutoSize = true;
            this.lbl_min.Font = new System.Drawing.Font("Cambria", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_min.Location = new System.Drawing.Point(103, 20);
            this.lbl_min.Name = "lbl_min";
            this.lbl_min.Size = new System.Drawing.Size(17, 12);
            this.lbl_min.TabIndex = 25;
            this.lbl_min.Text = "00";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(198, 44);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(22, 13);
            this.label13.TabIndex = 19;
            this.label13.Text = "sec";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(123, 44);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(25, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "min";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(11, 46);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(34, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "START";
            // 
            // btn_auto_start_end
            // 
            this.btn_auto_start_end.BackColor = System.Drawing.Color.Lime;
            this.btn_auto_start_end.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_auto_start_end.Location = new System.Drawing.Point(16, 458);
            this.btn_auto_start_end.Name = "btn_auto_start_end";
            this.btn_auto_start_end.Size = new System.Drawing.Size(260, 33);
            this.btn_auto_start_end.TabIndex = 5;
            this.btn_auto_start_end.Text = "SET TIME";
            this.btn_auto_start_end.UseVisualStyleBackColor = false;
            this.btn_auto_start_end.Click += new System.EventHandler(this.btn_auto_start_end_Click);
            this.btn_auto_start_end.MouseLeave += new System.EventHandler(this.btn_auto_start_end_MouseLeave);
            this.btn_auto_start_end.MouseHover += new System.EventHandler(this.btn_auto_start_end_MouseHover);
            // 
            // btn_submit
            // 
            this.btn_submit.BackColor = System.Drawing.Color.Lime;
            this.btn_submit.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_submit.Location = new System.Drawing.Point(15, 425);
            this.btn_submit.Name = "btn_submit";
            this.btn_submit.Size = new System.Drawing.Size(260, 33);
            this.btn_submit.TabIndex = 4;
            this.btn_submit.Text = "SUBMIT";
            this.btn_submit.UseVisualStyleBackColor = false;
            this.btn_submit.Click += new System.EventHandler(this.btn_submit_Click_1);
            this.btn_submit.MouseLeave += new System.EventHandler(this.btn_submit_MouseLeave);
            this.btn_submit.MouseHover += new System.EventHandler(this.btn_submit_MouseHover);
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.Transparent;
            this.groupBox7.Controls.Add(this.label15);
            this.groupBox7.Controls.Add(this.label14);
            this.groupBox7.Controls.Add(this.txtbox_hOfsset);
            this.groupBox7.Controls.Add(this.txtbox_vOffset);
            this.groupBox7.Controls.Add(this.comboBox_Playout);
            this.groupBox7.Controls.Add(this.comboBox_Textcrawl);
            this.groupBox7.Controls.Add(this.comboBox_Logo);
            this.groupBox7.Controls.Add(this.radioButton_rSD);
            this.groupBox7.Controls.Add(this.radioButton_rHD);
            this.groupBox7.Controls.Add(this.label6);
            this.groupBox7.Controls.Add(this.label5);
            this.groupBox7.Controls.Add(this.label7);
            this.groupBox7.ForeColor = System.Drawing.Color.White;
            this.groupBox7.Location = new System.Drawing.Point(16, 140);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(259, 172);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "File";
            // 
            // comboBox_Playout
            // 
            this.comboBox_Playout.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_Playout.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_Playout.FontSize = MetroFramework.MetroComboBoxSize.Small;
            this.comboBox_Playout.FormattingEnabled = true;
            this.comboBox_Playout.ItemHeight = 19;
            this.comboBox_Playout.Location = new System.Drawing.Point(80, 108);
            this.comboBox_Playout.Name = "comboBox_Playout";
            this.comboBox_Playout.Size = new System.Drawing.Size(141, 25);
            this.comboBox_Playout.TabIndex = 7;
            this.comboBox_Playout.UseCustomBackColor = true;
            this.comboBox_Playout.UseCustomForeColor = true;
            this.comboBox_Playout.UseSelectable = true;
            // 
            // comboBox_Textcrawl
            // 
            this.comboBox_Textcrawl.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_Textcrawl.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_Textcrawl.FontSize = MetroFramework.MetroComboBoxSize.Small;
            this.comboBox_Textcrawl.FormattingEnabled = true;
            this.comboBox_Textcrawl.ItemHeight = 19;
            this.comboBox_Textcrawl.Location = new System.Drawing.Point(80, 64);
            this.comboBox_Textcrawl.Name = "comboBox_Textcrawl";
            this.comboBox_Textcrawl.Size = new System.Drawing.Size(141, 25);
            this.comboBox_Textcrawl.TabIndex = 6;
            this.comboBox_Textcrawl.UseCustomBackColor = true;
            this.comboBox_Textcrawl.UseCustomForeColor = true;
            this.comboBox_Textcrawl.UseSelectable = true;
            // 
            // comboBox_Logo
            // 
            this.comboBox_Logo.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox_Logo.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_Logo.FontSize = MetroFramework.MetroComboBoxSize.Small;
            this.comboBox_Logo.FormattingEnabled = true;
            this.comboBox_Logo.ItemHeight = 19;
            this.comboBox_Logo.Location = new System.Drawing.Point(81, 20);
            this.comboBox_Logo.Name = "comboBox_Logo";
            this.comboBox_Logo.Size = new System.Drawing.Size(141, 25);
            this.comboBox_Logo.TabIndex = 5;
            this.comboBox_Logo.UseCustomBackColor = true;
            this.comboBox_Logo.UseCustomForeColor = true;
            this.comboBox_Logo.UseSelectable = true;
            // 
            // radioButton_rSD
            // 
            this.radioButton_rSD.AutoSize = true;
            this.radioButton_rSD.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_rSD.ForeColor = System.Drawing.Color.White;
            this.radioButton_rSD.Location = new System.Drawing.Point(79, 135);
            this.radioButton_rSD.Name = "radioButton_rSD";
            this.radioButton_rSD.Size = new System.Drawing.Size(37, 17);
            this.radioButton_rSD.TabIndex = 18;
            this.radioButton_rSD.TabStop = true;
            this.radioButton_rSD.Text = "SD";
            this.radioButton_rSD.UseVisualStyleBackColor = true;
            this.radioButton_rSD.CheckedChanged += new System.EventHandler(this.radioButton_rSD_CheckedChanged_1);
            // 
            // radioButton_rHD
            // 
            this.radioButton_rHD.AutoSize = true;
            this.radioButton_rHD.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_rHD.ForeColor = System.Drawing.Color.White;
            this.radioButton_rHD.Location = new System.Drawing.Point(165, 135);
            this.radioButton_rHD.Name = "radioButton_rHD";
            this.radioButton_rHD.Size = new System.Drawing.Size(39, 17);
            this.radioButton_rHD.TabIndex = 17;
            this.radioButton_rHD.TabStop = true;
            this.radioButton_rHD.Text = "HD";
            this.radioButton_rHD.UseVisualStyleBackColor = true;
            this.radioButton_rHD.CheckedChanged += new System.EventHandler(this.radioButton_rHD_CheckedChanged_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(11, 120);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "PLAYOUT";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(11, 77);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "TEXT CRAWL";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(11, 31);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(33, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "LOGO";
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.Transparent;
            this.groupBox6.Controls.Add(this.radioButton_BR_PNG);
            this.groupBox6.Controls.Add(this.radioButton_BL_PNG);
            this.groupBox6.Controls.Add(this.radioButton_TR_PNG);
            this.groupBox6.Controls.Add(this.radioButton_TL_PNG);
            this.groupBox6.ForeColor = System.Drawing.Color.White;
            this.groupBox6.Location = new System.Drawing.Point(16, 42);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(259, 88);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Logo Position";
            // 
            // radioButton_BR_PNG
            // 
            this.radioButton_BR_PNG.AutoSize = true;
            this.radioButton_BR_PNG.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_BR_PNG.ForeColor = System.Drawing.Color.White;
            this.radioButton_BR_PNG.Location = new System.Drawing.Point(150, 46);
            this.radioButton_BR_PNG.Name = "radioButton_BR_PNG";
            this.radioButton_BR_PNG.Size = new System.Drawing.Size(95, 17);
            this.radioButton_BR_PNG.TabIndex = 10;
            this.radioButton_BR_PNG.TabStop = true;
            this.radioButton_BR_PNG.Text = "BOTTOM RIGHT";
            this.radioButton_BR_PNG.UseVisualStyleBackColor = true;
            this.radioButton_BR_PNG.CheckedChanged += new System.EventHandler(this.radioButton_BR_PNG_CheckedChanged);
            // 
            // radioButton_BL_PNG
            // 
            this.radioButton_BL_PNG.AutoSize = true;
            this.radioButton_BL_PNG.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_BL_PNG.ForeColor = System.Drawing.Color.White;
            this.radioButton_BL_PNG.Location = new System.Drawing.Point(150, 21);
            this.radioButton_BL_PNG.Name = "radioButton_BL_PNG";
            this.radioButton_BL_PNG.Size = new System.Drawing.Size(87, 17);
            this.radioButton_BL_PNG.TabIndex = 9;
            this.radioButton_BL_PNG.TabStop = true;
            this.radioButton_BL_PNG.Text = "BOTTOM LEFT";
            this.radioButton_BL_PNG.UseVisualStyleBackColor = true;
            this.radioButton_BL_PNG.CheckedChanged += new System.EventHandler(this.radioButton_BL_PNG_CheckedChanged);
            // 
            // radioButton_TR_PNG
            // 
            this.radioButton_TR_PNG.AutoSize = true;
            this.radioButton_TR_PNG.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_TR_PNG.ForeColor = System.Drawing.Color.White;
            this.radioButton_TR_PNG.Location = new System.Drawing.Point(6, 46);
            this.radioButton_TR_PNG.Name = "radioButton_TR_PNG";
            this.radioButton_TR_PNG.Size = new System.Drawing.Size(73, 17);
            this.radioButton_TR_PNG.TabIndex = 8;
            this.radioButton_TR_PNG.TabStop = true;
            this.radioButton_TR_PNG.Text = "TOP RIGHT";
            this.radioButton_TR_PNG.UseVisualStyleBackColor = true;
            this.radioButton_TR_PNG.CheckedChanged += new System.EventHandler(this.radioButton_TR_PNG_CheckedChanged);
            // 
            // radioButton_TL_PNG
            // 
            this.radioButton_TL_PNG.AutoSize = true;
            this.radioButton_TL_PNG.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton_TL_PNG.ForeColor = System.Drawing.Color.White;
            this.radioButton_TL_PNG.Location = new System.Drawing.Point(6, 21);
            this.radioButton_TL_PNG.Name = "radioButton_TL_PNG";
            this.radioButton_TL_PNG.Size = new System.Drawing.Size(65, 17);
            this.radioButton_TL_PNG.TabIndex = 7;
            this.radioButton_TL_PNG.TabStop = true;
            this.radioButton_TL_PNG.Text = "TOP LEFT";
            this.radioButton_TL_PNG.UseVisualStyleBackColor = true;
            this.radioButton_TL_PNG.CheckedChanged += new System.EventHandler(this.radioButton_TL_PNG_CheckedChanged);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Controls.Add(this.label4);
            this.panel5.Location = new System.Drawing.Point(0, 2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(290, 28);
            this.panel5.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(59, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(178, 19);
            this.label4.TabIndex = 5;
            this.label4.Text = "Transformation Property";
            // 
            // CHANNELS
            // 
            this.CHANNELS.CheckBoxes = true;
            this.CHANNELS.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CHANNELS.HideSelection = false;
            this.CHANNELS.Location = new System.Drawing.Point(6, 24);
            this.CHANNELS.Name = "CHANNELS";
            this.CHANNELS.Size = new System.Drawing.Size(717, 496);
            this.CHANNELS.TabIndex = 0;
            this.CHANNELS.UseCompatibleStateImageBehavior = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.White;
            this.groupBox1.Controls.Add(this.lbl_time);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.lbl_date);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Location = new System.Drawing.Point(6, 14);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(234, 649);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            // 
            // lbl_time
            // 
            this.lbl_time.AutoSize = true;
            this.lbl_time.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_time.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.lbl_time.Location = new System.Drawing.Point(69, 165);
            this.lbl_time.Name = "lbl_time";
            this.lbl_time.Size = new System.Drawing.Size(28, 15);
            this.lbl_time.TabIndex = 8;
            this.lbl_time.Text = "XXX";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label12.Location = new System.Drawing.Point(27, 165);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 15);
            this.label12.TabIndex = 7;
            this.label12.Text = "Time:";
            // 
            // lbl_date
            // 
            this.lbl_date.AutoSize = true;
            this.lbl_date.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_date.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.lbl_date.Location = new System.Drawing.Point(70, 152);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(28, 15);
            this.lbl_date.TabIndex = 6;
            this.lbl_date.Text = "XXX";
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::GUI.Properties.Resources._1155040;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Location = new System.Drawing.Point(-3, 183);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(237, 466);
            this.panel1.TabIndex = 3;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.btn_playout);
            this.groupBox2.Controls.Add(this.btn_textcrawl);
            this.groupBox2.Controls.Add(this.panel7);
            this.groupBox2.Controls.Add(this.btnlogo);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(9, 107);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(214, 353);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            // 
            // btn_playout
            // 
            this.btn_playout.BackColor = System.Drawing.Color.Lime;
            this.btn_playout.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_playout.Location = new System.Drawing.Point(22, 248);
            this.btn_playout.Name = "btn_playout";
            this.btn_playout.Size = new System.Drawing.Size(166, 89);
            this.btn_playout.TabIndex = 5;
            this.btn_playout.Text = "ON PLAYOUT";
            this.btn_playout.UseVisualStyleBackColor = false;
            this.btn_playout.Click += new System.EventHandler(this.btn_playout_Click);
            this.btn_playout.MouseLeave += new System.EventHandler(this.btn_playout_MouseLeave);
            this.btn_playout.MouseHover += new System.EventHandler(this.btn_playout_MouseHover);
            // 
            // btn_textcrawl
            // 
            this.btn_textcrawl.BackColor = System.Drawing.Color.Lime;
            this.btn_textcrawl.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_textcrawl.Location = new System.Drawing.Point(22, 152);
            this.btn_textcrawl.Name = "btn_textcrawl";
            this.btn_textcrawl.Size = new System.Drawing.Size(166, 89);
            this.btn_textcrawl.TabIndex = 4;
            this.btn_textcrawl.Text = "ON TEXT CRAWL";
            this.btn_textcrawl.UseVisualStyleBackColor = false;
            this.btn_textcrawl.Click += new System.EventHandler(this.btn_textcrawl_Click);
            this.btn_textcrawl.MouseLeave += new System.EventHandler(this.btn_textcrawl_MouseLeave);
            this.btn_textcrawl.MouseHover += new System.EventHandler(this.btn_textcrawl_MouseHover);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Controls.Add(this.panel_enadis_menustrip);
            this.panel7.Controls.Add(this.label_ENA_DIS);
            this.panel7.Location = new System.Drawing.Point(0, 6);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(214, 31);
            this.panel7.TabIndex = 5;
            // 
            // panel_enadis_menustrip
            // 
            this.panel_enadis_menustrip.Controls.Add(this.pictureBox_enadis);
            this.panel_enadis_menustrip.Location = new System.Drawing.Point(6, 1);
            this.panel_enadis_menustrip.Name = "panel_enadis_menustrip";
            this.panel_enadis_menustrip.Size = new System.Drawing.Size(35, 28);
            this.panel_enadis_menustrip.TabIndex = 6;
            // 
            // pictureBox_enadis
            // 
            this.pictureBox_enadis.Image = global::GUI.Properties.Resources.hamburger_menu_512;
            this.pictureBox_enadis.Location = new System.Drawing.Point(6, 4);
            this.pictureBox_enadis.Name = "pictureBox_enadis";
            this.pictureBox_enadis.Size = new System.Drawing.Size(23, 20);
            this.pictureBox_enadis.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_enadis.TabIndex = 5;
            this.pictureBox_enadis.TabStop = false;
            this.pictureBox_enadis.Click += new System.EventHandler(this.pictureBox_enadis_Click);
            this.pictureBox_enadis.MouseLeave += new System.EventHandler(this.pictureBox_enadis_MouseLeave);
            this.pictureBox_enadis.MouseHover += new System.EventHandler(this.pictureBox_enadis_MouseHover);
            // 
            // label_ENA_DIS
            // 
            this.label_ENA_DIS.AutoSize = true;
            this.label_ENA_DIS.BackColor = System.Drawing.Color.White;
            this.label_ENA_DIS.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ENA_DIS.ForeColor = System.Drawing.Color.Black;
            this.label_ENA_DIS.Location = new System.Drawing.Point(74, 6);
            this.label_ENA_DIS.Name = "label_ENA_DIS";
            this.label_ENA_DIS.Size = new System.Drawing.Size(80, 22);
            this.label_ENA_DIS.TabIndex = 4;
            this.label_ENA_DIS.Text = "MODULES";
            // 
            // btnlogo
            // 
            this.btnlogo.BackColor = System.Drawing.Color.Lime;
            this.btnlogo.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnlogo.Location = new System.Drawing.Point(22, 58);
            this.btnlogo.Name = "btnlogo";
            this.btnlogo.Size = new System.Drawing.Size(166, 89);
            this.btnlogo.TabIndex = 3;
            this.btnlogo.Text = "ON LOGO";
            this.btnlogo.UseVisualStyleBackColor = false;
            this.btnlogo.Click += new System.EventHandler(this.btnlogo_Click_1);
            this.btnlogo.MouseLeave += new System.EventHandler(this.btnlogo_MouseLeave);
            this.btnlogo.MouseHover += new System.EventHandler(this.btnlogo_MouseHover);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.label11.Location = new System.Drawing.Point(27, 151);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(37, 15);
            this.label11.TabIndex = 5;
            this.label11.Text = "Date:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(125, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "XXX";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "MARKETING: ";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GUI.Properties.Resources._5a991c82be987_thumb900;
            this.pictureBox1.Location = new System.Drawing.Point(28, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(175, 91);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // metroPanel2
            // 
            this.metroPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.metroPanel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.metroPanel2.Controls.Add(this.pictureBox2);
            this.metroPanel2.Controls.Add(this.btn_hide);
            this.metroPanel2.Controls.Add(this.btn_refresh);
            this.metroPanel2.Controls.Add(this.btn_close);
            this.metroPanel2.Controls.Add(this.label1);
            this.metroPanel2.HorizontalScrollbarBarColor = true;
            this.metroPanel2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel2.HorizontalScrollbarSize = 10;
            this.metroPanel2.Location = new System.Drawing.Point(5, 6);
            this.metroPanel2.Name = "metroPanel2";
            this.metroPanel2.Size = new System.Drawing.Size(1332, 29);
            this.metroPanel2.TabIndex = 2;
            this.metroPanel2.UseCustomBackColor = true;
            this.metroPanel2.UseCustomForeColor = true;
            this.metroPanel2.VerticalScrollbarBarColor = true;
            this.metroPanel2.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel2.VerticalScrollbarSize = 10;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::GUI.Properties.Resources.LOGO3_resize;
            this.pictureBox2.Location = new System.Drawing.Point(3, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(30, 24);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // btn_hide
            // 
            this.btn_hide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_hide.BackgroundImage = global::GUI.Properties.Resources.minimize;
            this.btn_hide.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_hide.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_hide.ForeColor = System.Drawing.Color.White;
            this.btn_hide.Location = new System.Drawing.Point(1252, 0);
            this.btn_hide.Name = "btn_hide";
            this.btn_hide.Size = new System.Drawing.Size(34, 24);
            this.btn_hide.TabIndex = 5;
            this.btn_hide.UseVisualStyleBackColor = false;
            this.btn_hide.Click += new System.EventHandler(this.btn_hide_Click);
            // 
            // btn_refresh
            // 
            this.btn_refresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_refresh.BackgroundImage = global::GUI.Properties.Resources._50_512;
            this.btn_refresh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_refresh.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_refresh.ForeColor = System.Drawing.Color.White;
            this.btn_refresh.Location = new System.Drawing.Point(1212, 0);
            this.btn_refresh.Name = "btn_refresh";
            this.btn_refresh.Size = new System.Drawing.Size(34, 24);
            this.btn_refresh.TabIndex = 4;
            this.btn_refresh.UseVisualStyleBackColor = false;
            this.btn_refresh.Click += new System.EventHandler(this.btn_refresh_Click);
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_close.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close.ForeColor = System.Drawing.Color.White;
            this.btn_close.Location = new System.Drawing.Point(1291, 0);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(34, 24);
            this.btn_close.TabIndex = 3;
            this.btn_close.Text = "X";
            this.btn_close.UseVisualStyleBackColor = false;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click_1);
            this.btn_close.MouseLeave += new System.EventHandler(this.btn_close_MouseLeave);
            this.btn_close.MouseHover += new System.EventHandler(this.btn_close_MouseHover);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gainsboro;
            this.label1.Location = new System.Drawing.Point(32, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "GSAT AUTOMATION SYSTEM";
            // 
            // contextMenuStrip_EnaDis
            // 
            this.contextMenuStrip_EnaDis.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contextMenuStrip_EnaDis.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem_Ena,
            this.toolStripMenuItem_Dis});
            this.contextMenuStrip_EnaDis.Name = "contextMenuStrip_EnaDis";
            this.contextMenuStrip_EnaDis.Size = new System.Drawing.Size(128, 52);
            // 
            // toolStripMenuItem_Ena
            // 
            this.toolStripMenuItem_Ena.BackColor = System.Drawing.Color.Transparent;
            this.toolStripMenuItem_Ena.ForeColor = System.Drawing.Color.Black;
            this.toolStripMenuItem_Ena.Image = global::GUI.Properties.Resources.enable_icon_9;
            this.toolStripMenuItem_Ena.Name = "toolStripMenuItem_Ena";
            this.toolStripMenuItem_Ena.Size = new System.Drawing.Size(127, 24);
            this.toolStripMenuItem_Ena.Text = "Enable";
            this.toolStripMenuItem_Ena.Click += new System.EventHandler(this.toolStripMenuItem_Ena_Click);
            this.toolStripMenuItem_Ena.MouseLeave += new System.EventHandler(this.toolStripMenuItem_Ena_MouseLeave);
            this.toolStripMenuItem_Ena.MouseHover += new System.EventHandler(this.toolStripMenuItem_Ena_MouseHover);
            // 
            // toolStripMenuItem_Dis
            // 
            this.toolStripMenuItem_Dis.BackColor = System.Drawing.Color.Transparent;
            this.toolStripMenuItem_Dis.ForeColor = System.Drawing.Color.Black;
            this.toolStripMenuItem_Dis.Image = global::GUI.Properties.Resources.user_interface_switch_left_glyph_enable_disable_512;
            this.toolStripMenuItem_Dis.Name = "toolStripMenuItem_Dis";
            this.toolStripMenuItem_Dis.Size = new System.Drawing.Size(127, 24);
            this.toolStripMenuItem_Dis.Text = "Disable";
            this.toolStripMenuItem_Dis.Click += new System.EventHandler(this.toolStripMenuItem_Dis_Click);
            // 
            // timer_date_time
            // 
            this.timer_date_time.Interval = 1000;
            this.timer_date_time.Tick += new System.EventHandler(this.timer_date_time_Tick);
            // 
            // timer_playout_length
            // 
            this.timer_playout_length.Interval = 1000;
            this.timer_playout_length.Tick += new System.EventHandler(this.timer_playout_length_Tick);
            // 
            // timer_s
            // 
            this.timer_s.Interval = 10;
            this.timer_s.Tick += new System.EventHandler(this.timer_s_Tick);
            // 
            // txtbox_vOffset
            // 
            this.txtbox_vOffset.Location = new System.Drawing.Point(167, 152);
            this.txtbox_vOffset.Multiline = true;
            this.txtbox_vOffset.Name = "txtbox_vOffset";
            this.txtbox_vOffset.Size = new System.Drawing.Size(40, 15);
            this.txtbox_vOffset.TabIndex = 27;
            // 
            // txtbox_hOfsset
            // 
            this.txtbox_hOfsset.Location = new System.Drawing.Point(80, 152);
            this.txtbox_hOfsset.Multiline = true;
            this.txtbox_hOfsset.Name = "txtbox_hOfsset";
            this.txtbox_hOfsset.Size = new System.Drawing.Size(40, 15);
            this.txtbox_hOfsset.TabIndex = 28;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(123, 153);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(12, 13);
            this.label14.TabIndex = 29;
            this.label14.Text = "v";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(210, 154);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(13, 13);
            this.label15.TabIndex = 30;
            this.label15.Text = "h";
            // 
            // GUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::GUI.Properties.Resources._1155040;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1356, 718);
            this.Controls.Add(this.metroPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "GUI";
            this.Load += new System.EventHandler(this.GUI_Load);
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox_progressbar.ResumeLayout(false);
            this.groupBox_progressbar.PerformLayout();
            this.panel_file_list.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox_Scheduling.ResumeLayout(false);
            this.groupBox_Scheduling.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel_enadis_menustrip.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_enadis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.metroPanel2.ResumeLayout(false);
            this.metroPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.contextMenuStrip_EnaDis.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroPanel metroPanel3;
        private MetroFramework.Controls.MetroPanel metroPanel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_playout;
        private System.Windows.Forms.Button btn_textcrawl;
        private System.Windows.Forms.Button btnlogo;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ListView CHANNELS;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btn_auto_start_end;
        private System.Windows.Forms.Button btn_submit;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton radioButton_rSD;
        private System.Windows.Forms.RadioButton radioButton_rHD;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.RadioButton radioButton_BR_PNG;
        private System.Windows.Forms.RadioButton radioButton_BL_PNG;
        private System.Windows.Forms.RadioButton radioButton_TR_PNG;
        private System.Windows.Forms.RadioButton radioButton_TL_PNG;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel_file_list;
        private System.Windows.Forms.Button btn_proceed;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btn_close_selected_chan;
        private System.Windows.Forms.ListBox listBox_selected_Channels;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label_ENA_DIS;
        private System.Windows.Forms.Panel panel_enadis_menustrip;
        private System.Windows.Forms.PictureBox pictureBox_enadis;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip_EnaDis;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Ena;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem_Dis;
        private System.Windows.Forms.Label label4;
        private MetroFramework.Controls.MetroComboBox comboBox_Playout;
        private MetroFramework.Controls.MetroComboBox comboBox_Textcrawl;
        private MetroFramework.Controls.MetroComboBox comboBox_Logo;
        private System.Windows.Forms.GroupBox groupBox_Scheduling;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Timer timer_date_time;
        private System.Windows.Forms.Label lbl_time;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Timer timer_playout_length;
        private System.Windows.Forms.Timer timer_s;
        private System.Windows.Forms.Label lbl_playout;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lbl_mili_sec;
        private System.Windows.Forms.Label lbl_sec;
        private System.Windows.Forms.Label lbl_min;
        private System.Windows.Forms.Label lbl_start_end;
        private System.Windows.Forms.TextBox txtbox_sched_sec;
        private System.Windows.Forms.TextBox txtbox_sched_min;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btn_refresh;
        private System.Windows.Forms.GroupBox groupBox_progressbar;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lbl_pbar_await_min;
        private System.Windows.Forms.Label lbl_pbar_await_sec;
        private System.Windows.Forms.Button btn_hide;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtbox_hOfsset;
        private System.Windows.Forms.TextBox txtbox_vOffset;
    }
}

