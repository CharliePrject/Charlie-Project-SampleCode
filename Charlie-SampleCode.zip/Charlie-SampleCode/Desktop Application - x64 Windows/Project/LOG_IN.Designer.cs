﻿namespace GUI
{
    partial class LOG_IN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_file_list = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.metroTextBox_pass = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox_user = new MetroFramework.Controls.MetroTextBox();
            this.btn_login = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btn_hide = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_close = new System.Windows.Forms.Button();
            this.panel_file_list.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_file_list
            // 
            this.panel_file_list.BackColor = System.Drawing.Color.Transparent;
            this.panel_file_list.BackgroundImage = global::GUI.Properties.Resources._11550401;
            this.panel_file_list.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_file_list.Controls.Add(this.label3);
            this.panel_file_list.Controls.Add(this.label2);
            this.panel_file_list.Controls.Add(this.label1);
            this.panel_file_list.Controls.Add(this.metroTextBox_pass);
            this.panel_file_list.Controls.Add(this.metroTextBox_user);
            this.panel_file_list.Controls.Add(this.btn_login);
            this.panel_file_list.Controls.Add(this.panel6);
            this.panel_file_list.ForeColor = System.Drawing.Color.Gainsboro;
            this.panel_file_list.Location = new System.Drawing.Point(0, 1);
            this.panel_file_list.Name = "panel_file_list";
            this.panel_file_list.Size = new System.Drawing.Size(448, 233);
            this.panel_file_list.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gainsboro;
            this.label4.Location = new System.Drawing.Point(99, 5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(149, 17);
            this.label4.TabIndex = 21;
            this.label4.Text = "AUTHENTICATION";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(194, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(129, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Log in your GSAT  account?";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(37, 134);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 18);
            this.label2.TabIndex = 18;
            this.label2.Text = "Password:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(37, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 18);
            this.label1.TabIndex = 17;
            this.label1.Text = "Username:";
            // 
            // metroTextBox_pass
            // 
            // 
            // 
            // 
            this.metroTextBox_pass.CustomButton.Image = null;
            this.metroTextBox_pass.CustomButton.Location = new System.Drawing.Point(255, 2);
            this.metroTextBox_pass.CustomButton.Name = "";
            this.metroTextBox_pass.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.metroTextBox_pass.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox_pass.CustomButton.TabIndex = 1;
            this.metroTextBox_pass.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox_pass.CustomButton.UseSelectable = true;
            this.metroTextBox_pass.CustomButton.Visible = false;
            this.metroTextBox_pass.DisplayIcon = true;
            this.metroTextBox_pass.ForeColor = System.Drawing.Color.Black;
            this.metroTextBox_pass.Icon = global::GUI.Properties.Resources.key;
            this.metroTextBox_pass.IconRight = true;
            this.metroTextBox_pass.Lines = new string[0];
            this.metroTextBox_pass.Location = new System.Drawing.Point(118, 134);
            this.metroTextBox_pass.MaxLength = 32767;
            this.metroTextBox_pass.Multiline = true;
            this.metroTextBox_pass.Name = "metroTextBox_pass";
            this.metroTextBox_pass.PasswordChar = '*';
            this.metroTextBox_pass.PromptText = "Input Password here";
            this.metroTextBox_pass.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox_pass.SelectedText = "";
            this.metroTextBox_pass.SelectionLength = 0;
            this.metroTextBox_pass.SelectionStart = 0;
            this.metroTextBox_pass.ShortcutsEnabled = true;
            this.metroTextBox_pass.ShowClearButton = true;
            this.metroTextBox_pass.Size = new System.Drawing.Size(281, 28);
            this.metroTextBox_pass.TabIndex = 16;
            this.metroTextBox_pass.UseCustomBackColor = true;
            this.metroTextBox_pass.UseCustomForeColor = true;
            this.metroTextBox_pass.UseSelectable = true;
            this.metroTextBox_pass.WaterMark = "Input Password here";
            this.metroTextBox_pass.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox_pass.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.metroTextBox_pass.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.metroTextBox_pass_KeyPress);
            // 
            // metroTextBox_user
            // 
            // 
            // 
            // 
            this.metroTextBox_user.CustomButton.Image = null;
            this.metroTextBox_user.CustomButton.Location = new System.Drawing.Point(255, 2);
            this.metroTextBox_user.CustomButton.Name = "";
            this.metroTextBox_user.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.metroTextBox_user.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox_user.CustomButton.TabIndex = 1;
            this.metroTextBox_user.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox_user.CustomButton.UseSelectable = true;
            this.metroTextBox_user.CustomButton.Visible = false;
            this.metroTextBox_user.DisplayIcon = true;
            this.metroTextBox_user.ForeColor = System.Drawing.Color.Black;
            this.metroTextBox_user.Icon = global::GUI.Properties.Resources.person;
            this.metroTextBox_user.IconRight = true;
            this.metroTextBox_user.Lines = new string[0];
            this.metroTextBox_user.Location = new System.Drawing.Point(118, 93);
            this.metroTextBox_user.MaxLength = 32767;
            this.metroTextBox_user.Multiline = true;
            this.metroTextBox_user.Name = "metroTextBox_user";
            this.metroTextBox_user.PasswordChar = '\0';
            this.metroTextBox_user.PromptText = "Input User ID here";
            this.metroTextBox_user.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox_user.SelectedText = "";
            this.metroTextBox_user.SelectionLength = 0;
            this.metroTextBox_user.SelectionStart = 0;
            this.metroTextBox_user.ShortcutsEnabled = true;
            this.metroTextBox_user.ShowClearButton = true;
            this.metroTextBox_user.Size = new System.Drawing.Size(281, 28);
            this.metroTextBox_user.TabIndex = 15;
            this.metroTextBox_user.UseCustomBackColor = true;
            this.metroTextBox_user.UseCustomForeColor = true;
            this.metroTextBox_user.UseSelectable = true;
            this.metroTextBox_user.WaterMark = "Input User ID here";
            this.metroTextBox_user.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox_user.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.metroTextBox_user.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.metroTextBox_user_KeyPress);
            // 
            // btn_login
            // 
            this.btn_login.BackColor = System.Drawing.Color.Lime;
            this.btn_login.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_login.ForeColor = System.Drawing.Color.White;
            this.btn_login.Location = new System.Drawing.Point(331, 168);
            this.btn_login.Name = "btn_login";
            this.btn_login.Size = new System.Drawing.Size(68, 25);
            this.btn_login.TabIndex = 5;
            this.btn_login.Text = "LOG IN";
            this.btn_login.UseVisualStyleBackColor = false;
            this.btn_login.Click += new System.EventHandler(this.btn_login_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel6.Controls.Add(this.label4);
            this.panel6.Controls.Add(this.btn_hide);
            this.panel6.Controls.Add(this.pictureBox1);
            this.panel6.Controls.Add(this.btn_close);
            this.panel6.Location = new System.Drawing.Point(40, 5);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(359, 31);
            this.panel6.TabIndex = 14;
            // 
            // btn_hide
            // 
            this.btn_hide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_hide.BackgroundImage = global::GUI.Properties.Resources.minimize;
            this.btn_hide.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_hide.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_hide.ForeColor = System.Drawing.Color.White;
            this.btn_hide.Location = new System.Drawing.Point(280, 1);
            this.btn_hide.Name = "btn_hide";
            this.btn_hide.Size = new System.Drawing.Size(34, 24);
            this.btn_hide.TabIndex = 6;
            this.btn_hide.UseVisualStyleBackColor = false;
            this.btn_hide.Click += new System.EventHandler(this.btn_hide_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GUI.Properties.Resources.LOGO3_resize;
            this.pictureBox1.Location = new System.Drawing.Point(3, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(30, 28);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btn_close.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_close.ForeColor = System.Drawing.Color.White;
            this.btn_close.Location = new System.Drawing.Point(318, 1);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(34, 24);
            this.btn_close.TabIndex = 4;
            this.btn_close.Text = "X";
            this.btn_close.UseVisualStyleBackColor = false;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // LOG_IN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::GUI.Properties.Resources._1155040;
            this.ClientSize = new System.Drawing.Size(448, 236);
            this.Controls.Add(this.panel_file_list);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LOG_IN";
            this.Load += new System.EventHandler(this.LOG_IN_Load);
            this.panel_file_list.ResumeLayout(false);
            this.panel_file_list.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_file_list;
        private System.Windows.Forms.Button btn_login;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private MetroFramework.Controls.MetroTextBox metroTextBox_pass;
        private MetroFramework.Controls.MetroTextBox metroTextBox_user;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_hide;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}