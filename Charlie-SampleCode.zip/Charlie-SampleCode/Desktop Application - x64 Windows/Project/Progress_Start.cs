﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using MetroFramework.Forms;
using MetroFramework;

namespace GUI
{
    public partial class Progress_Start : Form
    {
        Random rd = new Random();
        double x, y;
        public Progress_Start()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            metroProgressBar1.Increment(1);
            x = Convert.ToInt32(metroProgressBar1.Value);
            y = (x / metroProgressBar1.Maximum) * 100;
            lbllaodpercent.Text = y.ToString() + " %";

            if (x == 100)
            {
                timer1.Stop();
                LOG_IN log_in = new LOG_IN();
                log_in.Show();
                this.Hide();
            }

        }

        private void lblloading_Click(object sender, EventArgs e)
        {

        }

        private void metroProgressBar1_Click(object sender, EventArgs e)
        {

        }

        private void lbllaodpercent_Click(object sender, EventArgs e)
        {

        }

        private void Progress_Start_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
            metroProgressBar1.Value = rd.Next(0, 101);


            timer1.Enabled = true;
            timer1.Start();
            lbllaodpercent.Text = y.ToString() + " %";
            y = (x / metroProgressBar1.Maximum) * 100;
            //--call 1 in form
            //lblloading.Text = c.ToString();
        }
    }
}
