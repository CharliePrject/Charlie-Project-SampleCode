﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using MetroFramework;
using MetroFramework.Forms;
using Npgsql;

namespace GUI
{
    public partial class LOG_IN : Form
    {
        string sr = "SERVER= ;PORT=;USERNAME=;PASSWORD=;DATABASE=";
        NpgsqlConnection conn = new NpgsqlConnection(sr);
        public LOG_IN()
        {
            InitializeComponent();
        }

        private void LOG_IN_Load(object sender, EventArgs e)
        {
            this.CenterToParent();
        }

        private void metroTextBox_user_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(metroTextBox_user.Text.Length >0 )
            {
                metroTextBox_user.DisplayIcon = false;
            }
            else 
            {
                metroTextBox_user.DisplayIcon = true;
            }
        }

     
        private void metroTextBox_pass_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (metroTextBox_pass.Text.Length >0)
            {
                metroTextBox_pass.DisplayIcon = false;
            }
            else
            {
                metroTextBox_pass.DisplayIcon = true;
            }
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if(metroTextBox_user.Text.Length <=0 && metroTextBox_pass.Text.Length <= 0)
            {
                metroTextBox_user.WithError = true;
                metroTextBox_pass.WithError = true;
            }
            else if(metroTextBox_user.Text.Length >=0 && metroTextBox_pass.Text.Length <= 0)
            {
                metroTextBox_user.WithError = true;
                metroTextBox_pass.WithError = false;
            }
            else if(metroTextBox_user.Text.Length <=0 && metroTextBox_pass.Text.Length >=0)
            {
                metroTextBox_user.WithError = false;
                metroTextBox_pass.WithError = true;
            }
            else
            {
                conn.Open();
                string account = "select*from '"+metroTextBox_user.Text+"'AND password = '"+metroTextBox_pass.Text+"'";
                NpgsqlCommand cmd = new NpgsqlCommand(account,conn);
                NpgsqlDataReader sdr  = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    MessageBox.Show("Successful","Security",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    GUI fr2 = new GUI();
                    fr2.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Wrong Account! Please try again.","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
                conn.Close();

            }
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_hide_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

       

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
