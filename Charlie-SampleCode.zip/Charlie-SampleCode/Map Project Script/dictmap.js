$(document).ready(function() {
  var a = [];
  var b = [];
  var lat = [];
  var lon = [];
  var sig_b = [];
  var macadd = [];
  var id = [];
  var sig_a = [];
  var name = [];
  var content;
  var infowindow = new google.maps.InfoWindow();


 
  var restictedArea={
    north:7.944265035386034,  
    south:5.475830847162561,  
    east:123.6931901181796,   
  };



  
   var Radius = 7000;
   var map = new google.maps.Map(document.getElementById('map'), {
      center: {lat: 5.98470, lng:120.15930 },
      zoom: 9,

       styles: [
      { elementType: "geometry", stylers: [{ color: "#242f3e" }] },
      { elementType: "labels.text.stroke", stylers: [{ color: "#242f3e" }] },
      { elementType: "labels.text.fill", stylers: [{ color: "#746855" }] },
      {
        featureType: "administrative.locality",
        elementType: "labels.text.fill",
        stylers: [{ color: "#d59563" }],
      },
      {
        featureType: "poi",
        elementType: "labels.text.fill",
        stylers: [{ color: "#d59563" }],
      },
      {
        featureType: "poi.park",
        elementType: "geometry",
        stylers: [{ color: "#263c3f" }],
      },
      {
        featureType: "poi.park",
        elementType: "labels.text.fill",
        stylers: [{ color: "#6b9a76" }],
      },
      {
        featureType: "road",
        elementType: "geometry",
        stylers: [{ color: "#38414e" }],
      },
      {
        featureType: "road",
        elementType: "geometry.stroke",
        stylers: [{ color: "#212a37" }],
      },
      {
        featureType: "water",
        elementType: "labels.text.fill",
        stylers: [{ color: "#515c6d" }],
      },
      {
        featureType: "water",
        elementType: "labels.text.stroke",
        stylers: [{ color: "#17263c" }],
      },
    ]
  });
   map.setOptions({ minZoom: 9, maxZoom: 15 });
   map.setMapTypeId('roadmap');
 
  
  var tf = new google.maps.TrafficLayer(); 
  tf.setMap(map);


   var input = document.getElementById('pac-input');
   var button = document.getElementById('buttonSearch');
   map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);


$.ajax({
    url: '/Examples',
    data: "",
    contentType: 'application/json',
    dataType : 'text',
    success: function(data)
    {
        var json=JSON.parse(data)
            for (var values in json){
             a.push(json[values]);
           }
         for(var x in a){
            b.push(a[x]);
         }

        
         for (var i = 0; i < b.length; i++) {
           lat.push(b[i].lat);
           lon.push(b[i].lon);
           sigb.push(b[i].avesno);
           macadd.push(b[i].macaddress);
           id.push(b[i].Id);
           siga.push(b[i].avecno);
           name.push(b[i].Name);
         }

        setInterval('window.location.reload()', 900000);
         for(i=0; i<b.length; i++){

          var Location = {lat: parseFloat(lat[i]), lng:parseFloat(lon[i])};

            
          if (sigb[i]>=10.50||sigb[i]==10.50){
              color='#00FF00';
         
         } else if(sigb[i]<=8.00||sigb==8.00){
              color='#FF0000';
          }else if(sigb[i]<=1.00 || sigb==1.00){
            color='#000000';
          }
           else {
              color='#FFFF00';
         }

          var circle = new google.maps.Circle({
            strokeColor: color,
            strokeOpacity: 0.8,
            strokeWeight: 5,
            fillColor: color,
            fillOpacity: .5,
            map: map,
            center: Location,
            radius: Radius
          });
          google.maps.event.addListener(map, 'zoom_changed', (function (circle, Radius, i) {
            return function () {
            var zoomLevel = map.getZoom();
              switch(true){
                case (zoomLevel<9):
                circle.setRadius(7000);
                break;
                case (zoomLevel>=9 && zoomLevel<=12):
                circle.setRadius(3500);
                break;
                case (zoomLevel>=13 && zoomLevel<=15):
                circle.setRadius(1750);
                break;
                case (zoomLevel>=15):
                circle.setRadius(875);
                break;
              }
            };
          })(circle, i));
          
          google.maps.event.addListener(circle, 'click', (function (marker, i) {
                return function () {
                  infowindow.setPosition(new google.maps.LatLng(lat[i], lon[i]));
                     content = '<div id="iw-container">' +
                    '<div class="iw-title"><i class="fa fa-spinner fa-spin fa-1x fa-fw"></i>&nbsp;IGSAT BROADBAND</div>' +
                    '<div class="iw-content">' +
                      '<div class="iw-subTitle"><i class="fa fa-info-circle" aria-hidden="true"></i>&nbsp;INFORMATION</div>' +
                          "<p><b>Name:</b>"+name[i]+
                          "<br>"+"<b>Mac Address:</b> "+macadd[i] +
                          "<br>"+"<b>Sit ID:</b> " +id[i]+
                          '<br><b>EsNo:</b>'+ sigb[i]+
                          '<br><b>Cno:</b> '+sigb[i]+
                          '<br><b>Latitude:</b> '+lat[i]+
                          '<br><b>Longitude:</b>'+lon[i]+
                          "</p>"+ 
                      '<div class="iw-subTitle"><i class="fa fa-phone" aria-hidden="true"></i>&nbsp;CONTACT</div>' +
                          '<b>Visit:</b> <a href = "http://gtelecoms.asia/">'+"http://gtelecoms.asia</a>"+
                          '<br><b>Phone:</b> +63 917-706-0149<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+63 917-836-6459<br><b>E-mail:</b> marketing@igsat.asia</p>'+
                    '</div>' +
                    '<div class="iw-bottom-gradient"></div>' +
                    '</div>';


                  infowindow.setContent(content);
                  infowindow.setOptions({maxWidth: 400});
                  infowindow.open(map, circle);
                };
          })(circle, i));
        }
       
        $('button').click(function() {

                var txtValue = $(input).val();


                for(i=0; i<b.length; i++){
                  if(txtValue == sit_id[i]){
                  map.setCenter({lat: parseFloat(latitude[i]), lng:parseFloat(longitude[i])});
                  map.setZoom(9);

                  infowindow.open(map, circle);

               } else if(txtValue == 0){
                  map.setCenter({lat: 5.98470, lng:120.15930 });
                  map.setZoom(9);

                 }

             }


                
        });
       
  }
 });
loadMapState();

google.maps.event.addListener(map, 'tilesloaded', tilesLoaded);
function tilesLoaded() {
    google.maps.event.clearListeners(map, 'tilesloaded');
    google.maps.event.addListener(map, 'zoom_changed', saveMapState);
    google.maps.event.addListener(map, 'dragend', saveMapState);
}


function saveMapState() {
    var mapZoom=map.getZoom();
    var mapCentre=map.getCenter();
    var mapLat=mapCentre.lat();
    var mapLng=mapCentre.lng();
    var cookiestring=mapLat+"_"+mapLng+"_"+mapZoom;
    setCookie("myMapCookie",cookiestring, 30);
}

function loadMapState() {
    var gotCookieString=getCookie("myMapCookie");
    var splitStr = gotCookieString.split("_");
    var savedMapLat = parseFloat(splitStr[0]);
    var savedMapLng = parseFloat(splitStr[1]);
    var savedMapZoom = parseFloat(splitStr[2]);
    if ((!isNaN(savedMapLat)) && (!isNaN(savedMapLng)) && (!isNaN(savedMapZoom))) {
        map.setCenter(new google.maps.LatLng(savedMapLat,savedMapLng));
        map.setZoom(savedMapZoom);
    }
}
});
